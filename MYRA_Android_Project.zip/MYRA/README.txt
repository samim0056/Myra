MYRA - Android AI Voice Assistant (full version)
1. Zip extract karo.
2. Android Studio -> File > Open -> MYRA folder select karo.
3. Gradle sync hone do, phir Run karo.
4. Settings me Gemini API key aur naam daalo, Save karo, app restart karo.
