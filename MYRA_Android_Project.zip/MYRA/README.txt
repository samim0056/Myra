MYRA - Android AI Voice Assistant

1. Android Studio -> File > Open -> is MYRA folder ko select karo (zip pehle extract karo).
2. Gradle sync hone do (Android Studio Gradle 8.2 khud download karega).
3. App run karo, permissions allow karo.
4. Settings me Gemini API key aur naam daalo, Save karo, app restart karo.
