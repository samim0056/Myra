package com.myra.assistant.ui.settings

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.myra.assistant.R
import com.myra.assistant.ai.GeminiLiveClient
import com.myra.assistant.model.PrimeContact
import com.myra.assistant.model.PrimeContactStore
import com.myra.assistant.service.AccessibilityHelperService

class SettingsActivity : AppCompatActivity() {

    private val models = listOf(
        "Native Audio (Human Voice) - DEFAULT" to "models/gemini-2.5-flash-native-audio-preview-12-2025",
        "Flash Live (Fast)" to "models/gemini-2.0-flash-live-001",
        "Pro Audio Dialog" to "models/gemini-2.5-flash-preview-native-audio-dialog"
    )
    private val voices = listOf(
        "Aoede (Female)" to "Aoede", "Charon (Male)" to "Charon", "Kore (Female)" to "Kore",
        "Fenrir (Male)" to "Fenrir", "Puck (Male)" to "Puck", "Leda (Female)" to "Leda",
        "Orus (Male)" to "Orus", "Zephyr (Female)" to "Zephyr"
    )

    private lateinit var apiKeyInput: EditText
    private lateinit var userNameInput: EditText
    private lateinit var modelSpinner: Spinner
    private lateinit var voiceSpinner: Spinner
    private lateinit var personalityGroup: RadioGroup
    private lateinit var accessibilityStatus: TextView
    private lateinit var primeRecycler: RecyclerView
    private lateinit var homeCityInput: EditText
    private lateinit var liveSearchSwitch: androidx.appcompat.widget.SwitchCompat

    private lateinit var contacts: MutableList<PrimeContact>
    private lateinit var primeAdapter: PrimeContactAdapter

    private val prefs by lazy { getSharedPreferences(GeminiLiveClient.PREFS, Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        apiKeyInput = findViewById(R.id.apiKeyInput)
        userNameInput = findViewById(R.id.userNameInput)
        modelSpinner = findViewById(R.id.modelSpinner)
        voiceSpinner = findViewById(R.id.voiceSpinner)
        personalityGroup = findViewById(R.id.personalityGroup)
        accessibilityStatus = findViewById(R.id.accessibilityStatus)
        primeRecycler = findViewById(R.id.primeRecycler)
        homeCityInput = findViewById(R.id.homeCityInput)
        liveSearchSwitch = findViewById(R.id.liveSearchSwitch)
        homeCityInput.setText(prefs.getString("home_city", ""))
        liveSearchSwitch.isChecked = prefs.getBoolean("live_search", true)

        apiKeyInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

        modelSpinner.adapter = darkAdapter(models.map { it.first })
        voiceSpinner.adapter = darkAdapter(voices.map { it.first })

        // load saved values
        apiKeyInput.setText(prefs.getString("api_key", ""))
        userNameInput.setText(prefs.getString("user_name", ""))
        val savedModel = prefs.getString("gemini_model", GeminiLiveClient.DEFAULT_MODEL)
        modelSpinner.setSelection(models.indexOfFirst { it.second == savedModel }.coerceAtLeast(0))
        val savedVoice = prefs.getString("gemini_voice", GeminiLiveClient.DEFAULT_VOICE)
        voiceSpinner.setSelection(voices.indexOfFirst { it.second == savedVoice }.coerceAtLeast(0))
        personalityGroup.check(
            when (prefs.getString("personality_mode", "GF")) {
                "PROFESSIONAL" -> R.id.radioPro
                "ASSISTANT" -> R.id.radioAssistant
                else -> R.id.radioGf
            }
        )

        // prime contacts
        contacts = PrimeContactStore.load(this)
        primeAdapter = PrimeContactAdapter(contacts) { pos ->
            contacts.removeAt(pos)
            primeAdapter.notifyItemRemoved(pos)
            primeAdapter.notifyItemRangeChanged(pos, contacts.size)
            PrimeContactStore.save(this, contacts)
        }
        primeRecycler.layoutManager = LinearLayoutManager(this)
        primeRecycler.adapter = primeAdapter
        findViewById<Button>(R.id.addPrimeBtn).setOnClickListener { showAddDialog() }

        accessibilityStatus.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<ImageButton>(R.id.backBtn).setOnClickListener { finish() }
        findViewById<Button>(R.id.saveBtn).setOnClickListener { save() }
    }

    override fun onResume() {
        super.onResume()
        val on = AccessibilityHelperService.isEnabled(this)
        accessibilityStatus.text = if (on) "✅ Accessibility ON" else "❌ Accessibility OFF (tap karke on karo)"
        accessibilityStatus.setTextColor(Color.parseColor(if (on) "#00E676" else "#FF1744"))
    }

    private fun save() {
        val mode = when (personalityGroup.checkedRadioButtonId) {
            R.id.radioPro -> "PROFESSIONAL"
            R.id.radioAssistant -> "ASSISTANT"
            else -> "GF"
        }
        prefs.edit()
            .putString("api_key", apiKeyInput.text.toString().trim())
            .putString("user_name", userNameInput.text.toString().trim())
            .putString("personality_mode", mode)
            .putString("gemini_model", models[modelSpinner.selectedItemPosition].second)
            .putString("gemini_voice", voices[voiceSpinner.selectedItemPosition].second)
            .putString("home_city", homeCityInput.text.toString().trim())
            .putBoolean("live_search", liveSearchSwitch.isChecked)
            .apply()
        PrimeContactStore.save(this, contacts)
        Toast.makeText(this, "Restart app to apply changes", Toast.LENGTH_LONG).show()
    }

    private fun showAddDialog() {
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_add_prime_contact, null)
        val nameIn = v.findViewById<EditText>(R.id.dialogNameInput)
        val numIn = v.findViewById<EditText>(R.id.dialogNumberInput)
        AlertDialog.Builder(this, com.google.android.material.R.style.ThemeOverlay_MaterialComponents_Dialog_Alert)
            .setTitle("Add Prime Contact")
            .setView(v)
            .setPositiveButton("ADD") { _, _ ->
                val n = nameIn.text.toString().trim()
                val num = numIn.text.toString().trim()
                if (n.isEmpty() || num.isEmpty()) {
                    Toast.makeText(this, "Name aur number dono daalo", Toast.LENGTH_SHORT).show()
                } else {
                    contacts.add(PrimeContact(n, num))
                    primeAdapter.notifyItemInserted(contacts.size - 1)
                    PrimeContactStore.save(this, contacts)
                }
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    /** Spinner adapter with light text on dark background. */
    private fun darkAdapter(labels: List<String>) =
        object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, labels) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
                (super.getView(position, convertView, parent) as TextView).apply {
                    setTextColor(Color.parseColor("#EEEEEE"))
                }
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View =
                (super.getDropDownView(position, convertView, parent) as TextView).apply {
                    setTextColor(Color.parseColor("#EEEEEE"))
                    setBackgroundColor(Color.parseColor("#111111"))
                    setPadding(32, 28, 32, 28)
                }
        }.also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
}

class PrimeContactAdapter(
    private val items: MutableList<PrimeContact>,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<PrimeContactAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.primeItemName)
        val number: TextView = v.findViewById(R.id.primeItemNumber)
        val delete: ImageButton = v.findViewById(R.id.primeItemDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_prime_contact, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = items[position]
        holder.name.text = "${position + 1}. ${c.name}"
        holder.number.text = c.number
        holder.delete.setOnClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onDelete(p)
        }
    }

    override fun getItemCount() = items.size
}
