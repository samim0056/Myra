package com.myra.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.*
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.myra.assistant.R
import com.myra.assistant.ui.main.MainActivity

/**
 * Foreground service that:
 *  - watches phone state (RINGING / IDLE) and hands incoming calls to MainActivity
 *  - hosts the dynamic PowerButtonReceiver (SCREEN_ON/OFF can't be declared in the manifest)
 */
class CallMonitorService : Service() {

    companion object {
        private const val CHANNEL_ID = "myra_call_channel"
        private const val NOTIF_ID = 1002
        private const val TAG = "CallMonitor"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var pendingAnnounce: Runnable? = null
    private var announced = false
    private val powerReceiver = PowerButtonReceiver()

    private val phoneReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.getStringExtra(TelephonyManager.EXTRA_STATE)) {
                TelephonyManager.EXTRA_STATE_RINGING -> {
                    if (announced) return
                    val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                    if (number != null) {
                        announce(number)
                    } else if (pendingAnnounce == null) {
                        // number sometimes arrives in a second broadcast
                        pendingAnnounce = Runnable { announce(null) }
                        handler.postDelayed(pendingAnnounce!!, 1200)
                    }
                }
                TelephonyManager.EXTRA_STATE_IDLE -> {
                    pendingAnnounce?.let { handler.removeCallbacks(it) }
                    pendingAnnounce = null
                    announced = false
                    sendBroadcast(Intent(MainActivity.ACTION_CALL_ENDED).setPackage(packageName))
                }
                else -> { /* OFFHOOK: call in progress */ }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notif = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL)
            } else startForeground(NOTIF_ID, notif)
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed", e)
            stopSelf(); return
        }
        ContextCompat.registerReceiver(this, phoneReceiver,
            IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED), ContextCompat.RECEIVER_EXPORTED)
        ContextCompat.registerReceiver(this, powerReceiver,
            IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON) },
            ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        runCatching { unregisterReceiver(phoneReceiver) }
        runCatching { unregisterReceiver(powerReceiver) }
        super.onDestroy()
    }

    private fun announce(number: String?) {
        pendingAnnounce?.let { handler.removeCallbacks(it) }
        pendingAnnounce = null
        announced = true
        val name = resolveCallerName(number)
        val i = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_INCOMING_CALL, true)
            putExtra(MainActivity.EXTRA_CALLER_NAME, name)
        }
        startActivity(i)
    }

    /** Matches the last 7+ digits of the incoming number against the contacts. */
    private fun resolveCallerName(number: String?): String {
        if (number.isNullOrBlank()) return "Unknown number"
        val incoming = number.filter { it.isDigit() }
        val tail = incoming.takeLast(minOf(10, incoming.length))
        if (tail.length >= 7) {
            try {
                contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER
                    ), null, null, null
                )?.use { c ->
                    while (c.moveToNext()) {
                        val digits = (c.getString(1) ?: "").filter { it.isDigit() }
                        if (digits.length >= 7 && digits.takeLast(7) == incoming.takeLast(7)) {
                            return c.getString(0) ?: number
                        }
                    }
                }
            } catch (e: SecurityException) {
                Log.w(TAG, "No contacts permission")
            }
        }
        return number
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "MYRA call monitor", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_myra_notif)
            .setContentTitle("MYRA")
            .setContentText("Call monitor active")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }
}
