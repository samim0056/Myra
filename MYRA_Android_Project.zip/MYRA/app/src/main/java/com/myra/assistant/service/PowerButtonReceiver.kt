package com.myra.assistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import androidx.core.content.ContextCompat

/**
 * Double power-button press = SCREEN_OFF followed by SCREEN_ON within 600 ms.
 * Registered dynamically by CallMonitorService (manifest registration of
 * SCREEN_ON/OFF is not delivered by Android).
 */
class PowerButtonReceiver : BroadcastReceiver() {

    private var lastAction: String? = null
    private var lastTime = 0L

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val now = SystemClock.elapsedRealtime()

        if (action == Intent.ACTION_SCREEN_ON &&
            lastAction == Intent.ACTION_SCREEN_OFF &&
            now - lastTime < 600
        ) {
            val show = Intent(context, MyraOverlayService::class.java).setAction(MyraOverlayService.ACTION_SHOW)
            if (MyraOverlayService.isRunning) context.startService(show)
            else ContextCompat.startForegroundService(context, show)
            lastAction = null
            return
        }
        lastAction = action
        lastTime = now
    }
}
