package com.myra.assistant.viewmodel

import android.Manifest
import android.annotation.SuppressLint
import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.app.SearchManager
import android.provider.ContactsContract
import android.provider.MediaStore
import android.view.KeyEvent
import com.myra.assistant.model.NoteStore
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import android.provider.Settings
import android.telecom.TelecomManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.myra.assistant.model.AppCommand
import com.myra.assistant.model.PrimeContactStore
import com.myra.assistant.service.AccessibilityHelperService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Executes phone commands. Every action returns a short result string that is sent back to Gemini. */
class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx: Context get() = getApplication<Application>()
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _commandResult = MutableLiveData<String?>()
    val commandResult: LiveData<String?> = _commandResult
    fun consumeResult() { _commandResult.value = null }

    private val appMap = mapOf(
        "youtube" to "com.google.android.youtube", "yt" to "com.google.android.youtube",
        "whatsapp" to "com.whatsapp", "instagram" to "com.instagram.android", "insta" to "com.instagram.android",
        "facebook" to "com.facebook.katana", "chrome" to "com.android.chrome",
        "gmail" to "com.google.android.gm", "maps" to "com.google.android.apps.maps",
        "google maps" to "com.google.android.apps.maps", "spotify" to "com.spotify.music",
        "netflix" to "com.netflix.mediaclient", "twitter" to "com.twitter.android", "x" to "com.twitter.android",
        "telegram" to "org.telegram.messenger", "snapchat" to "com.snapchat.android",
        "settings" to "com.android.settings", "calculator" to "com.google.android.calculator",
        "calendar" to "com.google.android.calendar", "clock" to "com.google.android.deskclock",
        "phone" to "com.google.android.dialer", "contacts" to "com.google.android.contacts",
        "play store" to "com.android.vending", "playstore" to "com.android.vending",
        "amazon" to "com.amazon.mShop.android.shopping", "flipkart" to "com.flipkart.android",
        "paytm" to "net.one97.paytm", "phonepe" to "com.phonepe.app",
        "gpay" to "com.google.android.apps.nbu.paisa.user", "google pay" to "com.google.android.apps.nbu.paisa.user",
        "zoom" to "us.zoom.videomeetings", "meet" to "com.google.android.apps.tachyon",
        "teams" to "com.microsoft.teams", "tiktok" to "com.zhiliaoapp.musically",
        "discord" to "com.discord", "linkedin" to "com.linkedin.android"
    )

    // ------------------------------------------------------------------ dispatch

    fun execute(cmd: AppCommand) {
        viewModelScope.launch(Dispatchers.IO) { _commandResult.postValue(runSafe(cmd)) }
    }

    /** Runs the command and hands the result string to [onDone] (used for Gemini tool responses). */
    fun executeAsync(cmd: AppCommand, onDone: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) { onDone(runSafe(cmd)) }
    }

    private suspend fun runSafe(cmd: AppCommand): String = try {
        run(cmd)
    } catch (e: SecurityException) {
        "Permission nahi mili: ${e.message}"
    } catch (e: Exception) {
        "Kaam nahi ho paya: ${e.message}"
    }

    private suspend fun run(cmd: AppCommand): String {
        val p = cmd.params
        return when (cmd.type) {
            AppCommand.OPEN_APP -> openApp(p["app_name"].orEmpty())
            AppCommand.CLOSE_APP -> closeApp()
            AppCommand.CALL -> call(resolveNumber(p) ?: return notFound(p))
            AppCommand.SMS -> sms(resolveNumber(p) ?: return notFound(p), p["message"])
            AppCommand.WHATSAPP_MSG -> whatsapp(resolveNumber(p) ?: return notFound(p), p["message"], false)
            AppCommand.WHATSAPP_CALL -> whatsapp(resolveNumber(p) ?: return notFound(p), null, true)
            AppCommand.PRIME_CALL -> prime(p, true)
            AppCommand.PRIME_MSG -> prime(p, false)
            AppCommand.VOLUME_UP -> volume(true)
            AppCommand.VOLUME_DOWN -> volume(false)
            AppCommand.FLASHLIGHT_ON -> torch(true)
            AppCommand.FLASHLIGHT_OFF -> torch(false)
            AppCommand.WIFI_ON -> wifi(true)
            AppCommand.WIFI_OFF -> wifi(false)
            AppCommand.BLUETOOTH_ON -> bluetooth(true)
            AppCommand.BLUETOOTH_OFF -> bluetooth(false)
            AppCommand.MEDIA_PLAY -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY, "Music chalu kar diya")
            AppCommand.MEDIA_PAUSE -> mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE, "Music pause kar diya")
            AppCommand.MEDIA_NEXT -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT, "Agla gaana laga diya")
            AppCommand.MEDIA_PREV -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS, "Pichla gaana laga diya")
            AppCommand.YOUTUBE_SEARCH -> youtubeSearch(p["query"].orEmpty())
            AppCommand.SCREENSHOT -> screenshot()
            AppCommand.CAMERA -> camera(p["mode"])
            AppCommand.NOTE_ADD -> { NoteStore.add(ctx, p["text"].orEmpty()); "Note save kar liya: ${p["text"]}" }
            AppCommand.NOTE_READ -> readNotes()
            AppCommand.NOTE_CLEAR -> { NoteStore.clear(ctx); "Saare notes delete kar diye" }
            AppCommand.WEATHER -> weather(p["city"])
            AppCommand.NEWS -> news(p["topic"])
            AppCommand.WEB_SEARCH -> webSearch(p["query"].orEmpty())
            else -> "Ye command samajh nahi aaya"
        }
    }

    private fun notFound(p: Map<String, String>) = "Contact '${p["name"] ?: p["number"] ?: ""}' nahi mila"

    // ------------------------------------------------------------------ apps

    private fun openApp(name: String): String {
        val key = name.lowercase().trim()
        val pm = ctx.packageManager

        val pkg = appMap[key] ?: appMap.entries.firstOrNull { key.contains(it.key) && it.key.length > 2 }?.value
        var launch = pkg?.let { pm.getLaunchIntentForPackage(it) }

        if (launch == null) {
            // Fallback: scan installed launcher apps by label
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val match = pm.queryIntentActivities(query, 0).firstOrNull {
                it.loadLabel(pm).toString().lowercase().let { l -> l == key || l.contains(key) }
            }
            launch = match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        }
        if (launch == null) return "'$name' app phone me nahi mila"
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(launch)
        return "$name khul gaya"
    }

    private fun closeApp(): String {
        if (!ensureAccessibility()) return "Accessibility service band hai, maine settings khol di hai. Usse on karo"
        AccessibilityHelperService.instance?.closeCurrentApp()
        return "App band kar diya, home screen par aa gaye"
    }

    /** If accessibility is off: Toast + open settings; the command is NOT executed. */
    private fun ensureAccessibility(): Boolean {
        if (AccessibilityHelperService.isEnabled(ctx) && AccessibilityHelperService.instance != null) return true
        mainHandler.post {
            Toast.makeText(ctx, "MYRA Accessibility service on karo", Toast.LENGTH_LONG).show()
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        return false
    }

    // ------------------------------------------------------------------ calls / messages

    private fun has(perm: String) = ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

    private fun call(number: String): String {
        if (!has(Manifest.permission.CALL_PHONE)) return "Call ki permission nahi hai"
        ctx.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Call laga di"
    }

    private fun sms(number: String, body: String?): String {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("smsto:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!body.isNullOrBlank()) i.putExtra("sms_body", body)
        ctx.startActivity(i)
        return "SMS screen khol di"
    }

    private suspend fun whatsapp(number: String, text: String?, voiceCall: Boolean): String {
        var digits = number.filter { it.isDigit() }
        if (digits.length == 10) digits = "91$digits"
        val url = "https://wa.me/$digits" + if (!text.isNullOrBlank()) "?text=" + Uri.encode(text) else ""
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        if (!voiceCall) return "WhatsApp chat khol di"

        if (!ensureAccessibility()) return "WhatsApp call ke liye Accessibility on karo"
        delay(3000)
        val ok = AccessibilityHelperService.instance?.clickOnText("Voice call") == true
        return if (ok) "WhatsApp call laga di" else "WhatsApp chat khul gayi, call button nahi mila"
    }

    private fun prime(p: Map<String, String>, isCall: Boolean): String {
        val list = PrimeContactStore.load(ctx)
        val index = p["index"]?.toIntOrNull() ?: 0
        val c = list.getOrNull(index) ?: return "Prime contact set nahi hai. Settings me add karo"
        return if (isCall) call(c.number) + " (${c.name})" else sms(c.number, p["message"]) + " (${c.name})"
    }

    private fun resolveNumber(p: Map<String, String>): String? {
        p["number"]?.let { return it }
        val name = p["name"] ?: return null
        // Allow naming a prime contact directly
        PrimeContactStore.load(ctx).firstOrNull { it.name.equals(name, true) }?.let { return it.number }
        return lookupContact(name)
    }

    /** Query ContactsContract Phone table; exact name first, then partial. */
    private fun lookupContact(name: String): String? {
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val proj = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        var partial: String? = null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, proj,
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                if (n.equals(name, true)) return num
                if (partial == null) partial = num
            }
        }
        return partial
    }

    @SuppressLint("MissingPermission")
    fun acceptCall() {
        viewModelScope.launch(Dispatchers.IO) {
            val r = try {
                val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                tm.acceptRingingCall(); "Call utha li"
            } catch (e: Exception) { "Call utha nahi paayi: ${e.message}" }
            _commandResult.postValue(r)
        }
    }

    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    fun rejectCall() {
        viewModelScope.launch(Dispatchers.IO) {
            val r = try {
                val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                tm.endCall(); "Call reject kar di"
            } catch (e: Exception) { "Call reject nahi hui: ${e.message}" }
            _commandResult.postValue(r)
        }
    }

    // ------------------------------------------------------------------ device controls

    private fun volume(up: Boolean): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        repeat(2) {
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            )
        }
        return if (up) "Volume badha diya" else "Volume kam kar diya"
    }

    private fun torch(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Is phone me flashlight nahi hai"
        cm.setTorchMode(id, on)
        return if (on) "Torch on kar di" else "Torch off kar di"
    }

    @Suppress("DEPRECATION")
    private fun wifi(on: Boolean): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ does not let apps toggle WiFi, so open the system panel
            ctx.startActivity(Intent(Settings.Panel.ACTION_WIFI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "WiFi panel khol diya, wahan se ${if (on) "on" else "off"} karo (Android 10+ me direct toggle allowed nahi)"
        }
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wm.isWifiEnabled = on
        return if (on) "WiFi on kar diya" else "WiFi off kar diya"
    }

    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    private fun bluetooth(on: Boolean): String {
        val adapter: BluetoothAdapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            ?: return "Is phone me Bluetooth nahi hai"
        val ok = try { if (on) adapter.enable() else adapter.disable() } catch (e: SecurityException) { false }
        if (ok) return if (on) "Bluetooth on kar diya" else "Bluetooth off kar diya"
        // Android 13+ blocks direct toggle, so fall back to system UI
        val i = if (on) Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE) else Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Bluetooth settings khol di, wahan se ${if (on) "on" else "off"} karo"
    }

    // ------------------------------------------------------------------ media / camera / notes

    private fun mediaKey(code: Int, ok: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ok
    }

    private fun youtubeSearch(query: String): String {
        val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
        val yt = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.youtube").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(yt)
        } catch (e: Exception) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        return "YouTube par '$query' ke results khol diye. Video par tap karna padega"
    }

    private fun screenshot(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return "Screenshot Android 9 ya usse upar par hi ho sakta hai"
        if (!ensureAccessibility()) return "Screenshot ke liye Accessibility on karo"
        val ok = AccessibilityHelperService.instance?.takeScreenshot() == true
        return if (ok) "Screenshot le liya, gallery me mil jayega" else "Screenshot nahi le paayi"
    }

    private fun camera(mode: String?): String {
        val i = when (mode) {
            "video" -> Intent(MediaStore.INTENT_ACTION_VIDEO_CAMERA)
            "selfie" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                .putExtra("android.intent.extras.CAMERA_FACING", 1)
                .putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
            else -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        }
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return when (mode) {
            "video" -> "Video camera khol diya"
            "selfie" -> "Selfie camera khol diya, shutter dabao"
            else -> "Camera khol diya, shutter dabao"
        }
    }

    private fun readNotes(): String {
        val notes = NoteStore.all(ctx)
        if (notes.isEmpty()) return "Koi note save nahi hai"
        return "Tumhare ${notes.size} notes: " + notes.takeLast(8).mapIndexed { i, n -> "${i + 1}) ${n.text}" }.joinToString(". ")
    }

    // ------------------------------------------------------------------ internet: weather / news / search

    private val http by lazy {
        OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(10, TimeUnit.SECONDS).build()
    }

    private fun httpGet(url: String): String? = try {
        http.newCall(Request.Builder().url(url).header("User-Agent", "MYRA/1.0").build()).execute().use {
            if (it.isSuccessful) it.body?.string() else null
        }
    } catch (e: Exception) { null }

    private fun weatherDesc(code: Int) = when (code) {
        0 -> "aasman saaf hai"
        1, 2 -> "halke badal hain"
        3 -> "badal chhaye hain"
        45, 48 -> "kohra hai"
        51, 53, 55, 56, 57 -> "halki phuhar ho rahi hai"
        61, 63, 65, 66, 67 -> "barish ho rahi hai"
        71, 73, 75, 77, 85, 86 -> "barfbari ho rahi hai"
        80, 81, 82 -> "barish ki tez bauchhar hai"
        95, 96, 99 -> "bijli ke saath toofan hai"
        else -> "mausam mila-jula hai"
    }

    private fun weather(cityParam: String?): String {
        val city = cityParam?.takeIf { it.isNotBlank() }
            ?: prefs().getString("home_city", "")?.takeIf { it.isNotBlank() }
            ?: return "Kis shehar ka mausam bataun? Ya Settings me Home city set karo"
        val geo = httpGet("https://geocoding-api.open-meteo.com/v1/search?name=${Uri.encode(city)}&count=1&language=en&format=json")
            ?: return "Internet ya weather service me problem hai"
        val results = JSONObject(geo).optJSONArray("results") ?: return "'$city' shehar nahi mila"
        val r = results.getJSONObject(0)
        val name = r.optString("name", city)
        val data = httpGet(
            "https://api.open-meteo.com/v1/forecast?latitude=${r.getDouble("latitude")}&longitude=${r.getDouble("longitude")}" +
                "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&timezone=auto"
        ) ?: return "Mausam ka data nahi mila"
        val cur = JSONObject(data).getJSONObject("current")
        return "$name me abhi ${Math.round(cur.getDouble("temperature_2m"))} degree Celsius hai, " +
            "mehsoos ${Math.round(cur.getDouble("apparent_temperature"))} degree jaisa, ${weatherDesc(cur.getInt("weather_code"))}. " +
            "Humidity ${cur.getInt("relative_humidity_2m")} percent, hawa ${Math.round(cur.getDouble("wind_speed_10m"))} km/h"
    }

    private fun cleanXml(s: String): String = s
        .replace("<![CDATA[", "").replace("]]>", "")
        .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
        .replace("&lt;", "<").replace("&gt;", ">").trim()

    private fun news(topic: String?): String {
        val url = if (topic.isNullOrBlank()) "https://news.google.com/rss?hl=hi&gl=IN&ceid=IN:hi"
        else "https://news.google.com/rss/search?q=${Uri.encode(topic)}&hl=hi&gl=IN&ceid=IN:hi"
        val xml = httpGet(url) ?: return "Khabrein load nahi ho payi, internet check karo"
        val titles = Regex("<item>.*?<title>(.*?)</title>", RegexOption.DOT_MATCHES_ALL)
            .findAll(xml).map { cleanXml(it.groupValues[1]).substringBeforeLast(" - ") }
            .filter { it.isNotBlank() }.take(5).toList()
        if (titles.isEmpty()) return "Is topic par koi khabar nahi mili"
        return (if (topic.isNullOrBlank()) "Aaj ki top khabrein: " else "$topic ki khabrein: ") +
            titles.mapIndexed { i, t -> "${i + 1}) $t" }.joinToString(". ")
    }

    private fun webSearch(query: String): String {
        try {
            ctx.startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
        return "Google par '$query' search khol diya"
    }

    private fun prefs() = ctx.getSharedPreferences("myra_prefs", Context.MODE_PRIVATE)
}
