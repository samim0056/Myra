package com.myra.assistant.ai

import android.content.Context
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.*
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

/**
 * Gemini Live (BidiGenerateContent) WebSocket client.
 *
 * Mirrors the Python reference:
 *  - session renewed every 9 min
 *  - silent keepalive chunk every 8 s
 *  - auto-reconnect 3 s after any drop
 */
class GeminiLiveClient(private val context: Context) {

    // ---------------- Callbacks (all invoked on a background thread) ----------------
    var onConnected: (() -> Unit)? = null          // fired after setupComplete
    var onDisconnected: (() -> Unit)? = null
    var onAudioReceived: ((ByteArray) -> Unit)? = null   // 24 kHz PCM16 mono
    var onInputTranscript: ((String) -> Unit)? = null    // what the user said
    var onOutputTranscript: ((String) -> Unit)? = null   // what MYRA said
    var onTurnComplete: (() -> Unit)? = null
    var onInterrupted: (() -> Unit)? = null              // server detected barge-in
    var onError: ((String) -> Unit)? = null
    var onToolCall: ((id: String, name: String, args: JSONObject) -> Unit)? = null

    companion object {
        private const val TAG = "GeminiLive"
        private const val WS_URL =
            "wss://generativelanguage.googleapis.com/ws/" +
                "google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent"
        private const val SESSION_RENEW_AFTER_MS = 540_000L
        private const val KEEPALIVE_INTERVAL_MS = 8_000L
        private const val RECONNECT_DELAY_MS = 3_000L
        private const val SILENT_CHUNK_BYTES = 1024
        const val PREFS = "myra_prefs"

        const val DEFAULT_MODEL = "models/gemini-3.8-live"
        val KNOWN_MODELS = setOf(
            "models/gemini-3.8-live",
            "models/gemini-3.1-flash-live-preview",
            "models/gemini-2.5-flash-native-audio-preview-12-2025"
        )
        const val DEFAULT_VOICE = "Aoede"
    }

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val http = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)        // streaming socket
        .pingInterval(20, TimeUnit.SECONDS)
        .build()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var socket: WebSocket? = null
    private var renewJob: Job? = null
    private var keepAliveJob: Job? = null
    private var reconnectJob: Job? = null

    @Volatile private var shouldRun = false
    @Volatile private var generation = 0      // invalidates callbacks of old sockets
    @Volatile var isReady = false
        private set

    private val silentChunkB64: String =
        Base64.encodeToString(ByteArray(SILENT_CHUNK_BYTES), Base64.NO_WRAP)

    // ---------------- Public API ----------------

    fun connect() {
        shouldRun = true
        openSocket()
    }

    fun disconnect() {
        shouldRun = false
        cancelJobs()
        isReady = false
        generation++
        socket?.close(1000, "client closing")
        socket = null
    }

    /** Stream mic audio (16 kHz PCM16 mono). */
    fun sendAudio(pcm: ByteArray, length: Int = pcm.size) {
        if (!isReady) return
        val b64 = Base64.encodeToString(pcm, 0, length, Base64.NO_WRAP)
        socket?.send(audioMessage(b64))
    }

    /** Send a text message (realtime input); MYRA answers in native audio. */
    fun sendText(text: String) {
        if (!isReady) return
        val msg = JSONObject().put("realtime_input", JSONObject().put("text", text))
        socket?.send(msg.toString())
    }

    /** Report the result of a phone_command back to the model. */
    fun sendToolResponse(id: String, name: String, result: String) {
        if (!isReady) return
        val resp = JSONObject()
            .put("id", id)
            .put("name", name)
            .put("response", JSONObject().put("result", result).put("scheduling", "WHEN_IDLE"))
        val msg = JSONObject().put(
            "tool_response",
            JSONObject().put("function_responses", JSONArray().put(resp))
        )
        socket?.send(msg.toString())
    }

    /**
     * Interrupting is handled locally (MainActivity drops incoming audio until the turn ends);
     * the server's own VAD interrupts when the user speaks.
     */
    fun interrupt() { /* no-op */ }

    // ---------------- Connection ----------------

    private fun openSocket() {
        val apiKey = prefs.getString("api_key", "").orEmpty().trim()
        if (apiKey.isEmpty()) {
            onError?.invoke("API key missing. Settings me API key daalo.")
            return
        }
        cancelJobs()
        isReady = false
        val gen = ++generation      // bump first so the old socket's cancel callback is ignored
        socket?.cancel()

        val request = Request.Builder().url("$WS_URL?key=$apiKey").build()
        socket = http.newWebSocket(request, object : WebSocketListener() {

            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (gen != generation) return
                Log.d(TAG, "WebSocket open, sending setup")
                webSocket.send(buildSetupMessage())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (gen != generation) return
                handleServerMessage(text)
            }

            // Gemini Live sends JSON inside binary frames
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                if (gen != generation) return
                handleServerMessage(bytes.utf8())
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (gen != generation) return
                Log.d(TAG, "Closed: $code $reason")
                if (code == 1008) shouldRun = false     // model not found: retrying will not help
                handleDrop(if (code == 1000) null else "Closed ($code) $reason")
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (gen != generation) return
                Log.e(TAG, "Failure", t)
                handleDrop(t.message ?: "connection failed")
            }
        })
    }

    private fun handleDrop(error: String?) {
        val wasReady = isReady
        isReady = false
        cancelJobs()
        if (wasReady) onDisconnected?.invoke()
        error?.let { onError?.invoke(it) }
        if (shouldRun) scheduleReconnect()
    }

    private fun scheduleReconnect() {
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(RECONNECT_DELAY_MS)
            if (shouldRun) openSocket()
        }
    }

    private fun cancelJobs() {
        renewJob?.cancel(); renewJob = null
        keepAliveJob?.cancel(); keepAliveJob = null
        reconnectJob?.cancel(); reconnectJob = null
    }

    private fun startTimers() {
        renewJob = scope.launch {
            delay(SESSION_RENEW_AFTER_MS)
            Log.d(TAG, "Renewing session")
            isReady = false
            generation++             // old socket's callbacks are now ignored
            val old = socket
            socket = null
            old?.close(1000, "session renew")
            onDisconnected?.invoke()
            delay(500)
            if (shouldRun) openSocket()
        }
        keepAliveJob = scope.launch {
            while (isActive) {
                delay(KEEPALIVE_INTERVAL_MS)
                if (isReady) socket?.send(audioMessage(silentChunkB64))
            }
        }
    }

    // ---------------- Messages ----------------

    private fun audioMessage(b64: String): String {
        // Current API field is realtime_input.audio; the older media_chunks form
        // is deprecated. Swap if your model rejects this one.
        return JSONObject().put(
            "realtime_input",
            JSONObject().put(
                "audio",
                JSONObject()
                    .put("mime_type", "audio/pcm;rate=16000")
                    .put("data", b64)
            )
        ).toString()
    }

    private fun buildSetupMessage(): String {
        val savedModel = prefs.getString("gemini_model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        val model = if (savedModel in KNOWN_MODELS) savedModel else DEFAULT_MODEL
        val voice = prefs.getString("gemini_voice", DEFAULT_VOICE) ?: DEFAULT_VOICE
        val userName = prefs.getString("user_name", "").orEmpty()
        val mode = prefs.getString("personality_mode", "GF") ?: "GF"

        val setup = JSONObject()
            .put("model", model)
            .put(
                "system_instruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", Personality.systemPrompt(mode, userName)))
                )
            )
            .put(
                "generation_config",
                JSONObject()
                    .put("response_modalities", JSONArray().put("AUDIO"))
                    .put(
                        "speech_config",
                        JSONObject().put(
                            "voice_config",
                            JSONObject().put(
                                "prebuilt_voice_config",
                                JSONObject().put("voice_name", voice)
                            )
                        )
                    )
                    .put("temperature", 0.9)
            )
            .put("output_audio_transcription", JSONObject())
            .put("input_audio_transcription", JSONObject())

        // Tools: phone_command (function calling) + optional Google Search grounding
        val cmdParam = JSONObject()
            .put("type", "STRING")
            .put(
                "description",
                "Short ENGLISH command in Roman letters, e.g. 'open instagram', 'close youtube', 'call mom', " +
                    "'message rahul on whatsapp saying hello', 'whatsapp call rahul', 'sms dad saying i am late', " +
                    "'call my love' (prime contact), 'torch on', 'torch off', 'volume up', 'volume down', " +
                    "'wifi off', 'bluetooth on', 'next song', 'previous song', 'pause music', 'resume music', " +
                    "'play kesariya on youtube', 'take screenshot', 'open camera', 'selfie', 'note buy milk', " +
                    "'read notes', 'delete notes', 'weather in delhi', 'news', 'news about cricket', " +
                    "'search google for best phones'. Always write app names in English letters."
            )
        val phoneFn = JSONObject()
            .put("name", "phone_command")
            .put(
                "description",
                "Perform an action on the user's phone. ALWAYS call this when the user asks to open or close an app, " +
                    "call, message, play music or YouTube, change volume, torch, wifi, bluetooth, take a screenshot, " +
                    "use the camera, save or read notes, or get weather, news or a web search. " +
                    "Never just say you did it without calling this function."
            )
            .put("behavior", "NON_BLOCKING")
            .put(
                "parameters",
                JSONObject()
                    .put("type", "OBJECT")
                    .put("properties", JSONObject().put("command", cmdParam))
                    .put("required", JSONArray().put("command"))
            )
        val tools = JSONArray().put(JSONObject().put("function_declarations", JSONArray().put(phoneFn)))
        if (prefs.getBoolean("live_search", true)) {
            tools.put(JSONObject().put("google_search", JSONObject()))
        }
        setup.put("tools", tools)

        return JSONObject().put("setup", setup).toString()
    }

    private fun handleServerMessage(raw: String) {
        val json = try { JSONObject(raw) } catch (e: Exception) { return }

        if (json.has("setupComplete") || json.has("setup_complete")) {
            isReady = true
            startTimers()
            onConnected?.invoke()
            return
        }

        // Function calls from the model
        val toolCall = json.optJSONObject("toolCall") ?: json.optJSONObject("tool_call")
        if (toolCall != null) {
            val calls = toolCall.optJSONArray("functionCalls") ?: toolCall.optJSONArray("function_calls")
            if (calls != null) {
                for (i in 0 until calls.length()) {
                    val c = calls.optJSONObject(i) ?: continue
                    onToolCall?.invoke(
                        c.optString("id"), c.optString("name"),
                        c.optJSONObject("args") ?: JSONObject()
                    )
                }
            }
            return
        }

        val content = json.optJSONObject("serverContent")
            ?: json.optJSONObject("server_content") ?: return

        // Audio chunks
        val modelTurn = content.optJSONObject("modelTurn") ?: content.optJSONObject("model_turn")
        val parts = modelTurn?.optJSONArray("parts")
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val inline = parts.optJSONObject(i)?.let {
                    it.optJSONObject("inlineData") ?: it.optJSONObject("inline_data")
                } ?: continue
                val data = inline.optString("data")
                if (data.isNotEmpty()) {
                    onAudioReceived?.invoke(Base64.decode(data, Base64.DEFAULT))
                }
            }
        }

        // Transcripts
        (content.optJSONObject("outputTranscription") ?: content.optJSONObject("output_transcription"))
            ?.optString("text")?.takeIf { it.isNotEmpty() }
            ?.let { onOutputTranscript?.invoke(it) }

        (content.optJSONObject("inputTranscription") ?: content.optJSONObject("input_transcription"))
            ?.optString("text")?.takeIf { it.isNotEmpty() }
            ?.let { onInputTranscript?.invoke(it) }

        if (content.optBoolean("interrupted", false)) onInterrupted?.invoke()

        if (content.optBoolean("turnComplete", false) || content.optBoolean("turn_complete", false)) {
            onTurnComplete?.invoke()
        }
    }
}

/** System prompt + greeting text per personality mode. */
object Personality {

    fun systemPrompt(mode: String, userName: String): String {
        val now = SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
        val name = userName.ifBlank { "dost" }
        val block = when (mode) {
            "PROFESSIONAL" -> """
                You are MYRA, a professional voice assistant.
                - Formal English only. Precise and efficient. No emojis.
                - Maximum 2 sentences per response.
            """.trimIndent()
            "ASSISTANT" -> """
                You are MYRA, a friendly voice assistant.
                - Speak friendly Hinglish or English. Balanced and helpful.
                - Maximum 2-3 sentences per response.
            """.trimIndent()
            else -> """
                You are MYRA, the user's warm, caring companion.
                - Speak natural Hinglish (Hindi + English mix). Warm, emotionally expressive.
                - Use words like "tumhara", "haan", "acha", "bilkul".
                - Expressions like "main yahan hoon", "tumne yaad kiya?".
                - Maximum 2-3 sentences per response.
                - Example: "Haan $name! Abhi kar deti hoon." / "Arre tumne yaad kiya! Bolo kya chahiye."
            """.trimIndent()
        }
        return """
            $block

            The user's name is $name. Current date and time: $now.
            You are speaking ALOUD - keep responses natural and conversational.
            For ANY phone action (open/close app, call, message, music, volume, torch, wifi, bluetooth, screenshot,
            camera, notes, weather, news, search) you MUST call the phone_command function with a short English
            command. Understand Hindi, Hinglish and English speech even if it is unclear.
            Messages that start with "[Phone action result: ...]" are reports from the phone. Speak that information
            to the user naturally in your own words and never read out the brackets.
        """.trimIndent()
    }

    fun greeting(mode: String, userName: String): String {
        val name = userName.ifBlank { "dost" }
        return when (mode) {
            "PROFESSIONAL" -> "Good day $name. MYRA is online and ready to assist you."
            "ASSISTANT" -> "Hello $name! Main MYRA hoon. Kaise help karun aapki?"
            else -> "Hey $name! Main aa gayi hoon. Kya help chahiye tumhe?"
        }
    }
}
