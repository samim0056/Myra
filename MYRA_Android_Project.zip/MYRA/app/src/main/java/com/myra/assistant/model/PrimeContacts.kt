package com.myra.assistant.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class PrimeContact(val name: String, val number: String)

/** Prime contacts stored as JSON array in SharedPreferences key `prime_contacts_json`. */
object PrimeContactStore {
    private const val PREFS = "myra_prefs"
    private const val KEY = "prime_contacts_json"

    fun load(ctx: Context): MutableList<PrimeContact> {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY, null)
        if (json == null) {
            // Legacy migration: old single prime contact keys
            val n = prefs.getString("prime_name", null)
            val num = prefs.getString("prime_number", null)
            if (!n.isNullOrBlank() && !num.isNullOrBlank()) {
                return mutableListOf(PrimeContact(n, num)).also { save(ctx, it) }
            }
            return mutableListOf()
        }
        val out = mutableListOf<PrimeContact>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(PrimeContact(o.optString("name"), o.optString("number")))
            }
        } catch (_: Exception) { }
        return out
    }

    fun save(ctx: Context, list: List<PrimeContact>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("name", it.name).put("number", it.number)) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
