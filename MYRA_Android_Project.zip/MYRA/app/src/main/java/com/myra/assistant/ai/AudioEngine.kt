package com.myra.assistant.ai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.util.Log
import androidx.core.content.ContextCompat
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

/**
 * Mic: 16 kHz mono PCM16 -> onMicChunk (to WebSocket)
 * Speaker: 24 kHz mono PCM16 <- queueAudio (from WebSocket)
 *
 * While MYRA is speaking, mic chunks are NOT forwarded (echo suppression).
 */
class AudioEngine(private val context: Context) {

    // ---------------- Callbacks (background threads) ----------------
    var onMicChunk: ((ByteArray) -> Unit)? = null
    var onAmplitudeChanged: ((Float) -> Unit)? = null   // 0..1
    var onSpeakingStarted: (() -> Unit)? = null
    var onSpeakingStopped: (() -> Unit)? = null

    companion object {
        private const val TAG = "AudioEngine"
        const val MIC_RATE = 16000
        const val SPEAKER_RATE = 24000
        const val CHUNK_BYTES = 1024
        private const val ECHO_HANGOVER_MS = 350L
        private const val IDLE_POLL_MS = 200L
    }

    @Volatile var isMuted = false
        private set
    @Volatile var isSpeaking = false
        private set

    private var recorder: AudioRecord? = null
    private var track: AudioTrack? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null

    private var micThread: Thread? = null
    private var playThread: Thread? = null
    @Volatile private var recording = false
    @Volatile private var playing = false

    private val queue = LinkedBlockingQueue<ByteArray>()
    @Volatile private var framesWritten = 0L
    @Volatile private var speakingEndedAt = 0L
    private val trackLock = Any()

    // ---------------- Recording ----------------

    fun startRecording() {
        if (recording) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            Log.w(TAG, "RECORD_AUDIO not granted")
            return
        }

        val minBuf = AudioRecord.getMinBufferSize(
            MIC_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MIC_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf, CHUNK_BYTES * 4)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, "AudioRecord init failed")
            rec.release()
            return
        }

        if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(rec.audioSessionId)?.also { it.enabled = true }
        if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(rec.audioSessionId)?.also { it.enabled = true }

        recorder = rec
        recording = true
        rec.startRecording()

        micThread = Thread({
            val buf = ByteArray(CHUNK_BYTES)
            while (recording) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue

                if (isMuted) {
                    if (!isSpeaking) onAmplitudeChanged?.invoke(0f)
                    continue
                }
                if (!isSpeaking) onAmplitudeChanged?.invoke(rms(buf, n))

                val inHangover = System.currentTimeMillis() - speakingEndedAt < ECHO_HANGOVER_MS
                if (!isSpeaking && !inHangover) {
                    onMicChunk?.invoke(if (n == buf.size) buf.copyOf() else buf.copyOf(n))
                }
            }
        }, "myra-mic").also { it.start() }
    }

    fun stopRecording() {
        recording = false
        micThread?.join(300)
        micThread = null
        runCatching { recorder?.stop() }
        recorder?.release(); recorder = null
        aec?.release(); aec = null
        ns?.release(); ns = null
    }

    // ---------------- Playback ----------------

    fun startPlayback() {
        if (playing) return
        val minBuf = AudioTrack.getMinBufferSize(
            SPEAKER_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(SPEAKER_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, SPEAKER_RATE)) // ~0.5 s
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        t.play()
        track = t
        playing = true

        playThread = Thread({
            while (playing) {
                val chunk = try {
                    queue.poll(IDLE_POLL_MS, TimeUnit.MILLISECONDS)
                } catch (e: InterruptedException) { break }

                if (chunk == null) {
                    // Queue drained: speaking ends once the hardware has played everything
                    if (isSpeaking && playbackFinished()) markSpeakingStopped()
                    continue
                }

                if (!isSpeaking) {
                    isSpeaking = true
                    onSpeakingStarted?.invoke()
                }
                onAmplitudeChanged?.invoke(rms(chunk, chunk.size))

                synchronized(trackLock) { /* serialises with clearPlayback */ }
                val written = track?.write(chunk, 0, chunk.size) ?: 0
                if (written > 0) framesWritten += written / 2
            }
        }, "myra-play").also { it.start() }
    }

    fun stopPlayback() {
        playing = false
        queue.clear()
        playThread?.interrupt()
        playThread = null
        track?.let {
            runCatching { it.stop() }
            it.release()
        }
        track = null
        isSpeaking = false
    }

    /** Add 24 kHz PCM16 audio from Gemini to the playback queue. */
    fun queueAudio(pcm: ByteArray) {
        if (pcm.isNotEmpty()) queue.offer(pcm)
    }

    /** Drop everything queued and silence the speaker immediately (barge-in). */
    fun clearPlayback() {
        queue.clear()
        synchronized(trackLock) {
            track?.let {
                runCatching {
                    it.pause()
                    it.flush()
                    it.play()
                }
            }
            framesWritten = 0
        }
        if (isSpeaking) markSpeakingStopped()
    }

    // ---------------- Controls ----------------

    fun setMuted(muted: Boolean) {
        isMuted = muted
        if (muted) onAmplitudeChanged?.invoke(0f)
    }

    fun release() {
        stopRecording()
        stopPlayback()
    }

    // ---------------- Helpers ----------------

    private fun playbackFinished(): Boolean {
        val t = track ?: return true
        return t.playbackHeadPosition.toLong() >= framesWritten - 240
    }

    private fun markSpeakingStopped() {
        isSpeaking = false
        speakingEndedAt = System.currentTimeMillis()
        framesWritten = 0
        onAmplitudeChanged?.invoke(0f)
        onSpeakingStopped?.invoke()
    }

    /** RMS of PCM16 little-endian bytes, normalised to 0..1 (boosted for visuals). */
    private fun rms(buf: ByteArray, len: Int): Float {
        var sum = 0.0
        var i = 0
        val samples = len / 2
        if (samples == 0) return 0f
        while (i + 1 < len) {
            val s = ((buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)).toShort().toInt()
            sum += s * s.toDouble()
            i += 2
        }
        val r = sqrt(sum / samples) / 32768.0
        return (r * 4.0).coerceIn(0.0, 1.0).toFloat()
    }
}
