package com.myra.assistant.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Voice notes stored locally as JSON in SharedPreferences (key `notes_json`). */
object NoteStore {
    private const val PREFS = "myra_prefs"
    private const val KEY = "notes_json"

    data class Note(val text: String, val time: String)

    fun all(ctx: Context): List<Note> {
        val json = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Note(o.optString("text"), o.optString("time"))
            }
        } catch (_: Exception) { emptyList() }
    }

    fun add(ctx: Context, text: String) {
        val list = all(ctx).toMutableList()
        val time = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date())
        list.add(Note(text, time))
        save(ctx, list)
    }

    fun clear(ctx: Context) = save(ctx, emptyList())

    private fun save(ctx: Context, list: List<Note>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("text", it.text).put("time", it.time)) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
