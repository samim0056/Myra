package com.myra.assistant.ui.main

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Canvas-drawn orb. Layers (back to front):
 * 1 radial glow, 2 core sphere, 3 rotating dashed rings, 4 wave rings,
 * 5 thinking arcs, 6 orbiting particles, 7 inner highlight.
 */
class OrbAnimationView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class State { IDLE, LISTENING, SPEAKING, THINKING }

    var state: State = State.IDLE
        private set

    // colour pairs (inner, outer) per state
    private val palette = mapOf(
        State.IDLE to (0xFFB71C1C.toInt() to 0xFF880E4F.toInt()),
        State.LISTENING to (0xFFFF1744.toInt() to 0xFFD500F9.toInt()),
        State.SPEAKING to (0xFFE040FB.toInt() to 0xFFFF1744.toInt()),
        State.THINKING to (0xFF40C4FF.toInt() to 0xFF00B0FF.toInt())
    )
    private var curInner = palette.getValue(State.IDLE).first
    private var curOuter = palette.getValue(State.IDLE).second

    private var amplitude = 0f
    private var smoothAmp = 0f
    private var pulse = 1f               // idle scale 1 -> 1.15
    private var glowAlpha = 120
    private var rotationAngle = 0f
    private var waveOffset = 0f
    private var thinkingAngle = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val path = Path()
    private val arcRect = RectF()

    private val animators = mutableListOf<ValueAnimator>()
    private var colorAnimator: ValueAnimator? = null

    // ---------------------------------------------------------------- API

    fun setState(newState: State) {
        if (newState == state) return
        state = newState
        val (ti, to) = palette.getValue(newState)
        val fromI = curInner; val fromO = curOuter
        colorAnimator?.cancel()
        colorAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 300
            addUpdateListener {
                val f = it.animatedValue as Float
                curInner = ArgbEvaluator().evaluate(f, fromI, ti) as Int
                curOuter = ArgbEvaluator().evaluate(f, fromO, to) as Int
                invalidate()
            }
            start()
        }
    }

    /** 0..1 RMS from AudioEngine. */
    fun setAmplitude(rms: Float) {
        amplitude = rms.coerceIn(0f, 1f)
        smoothAmp += (amplitude - smoothAmp) * 0.35f
        invalidate()
    }

    // ---------------------------------------------------------------- animators

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animators += ValueAnimator.ofFloat(0f, 1f).apply {            // idle pulse 1500ms
            duration = 1500; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                val f = it.animatedValue as Float
                pulse = 1f + 0.15f * f
                glowAlpha = (120 + 100 * f).toInt()
                invalidate()
            }
        }
        animators += ValueAnimator.ofFloat(0f, 360f).apply {          // ring rotation
            duration = 9000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { rotationAngle = it.animatedValue as Float; invalidate() }
        }
        animators += ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {   // wave phase
            duration = 1800; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { waveOffset = it.animatedValue as Float; invalidate() }
        }
        animators += ValueAnimator.ofFloat(0f, 360f).apply {          // thinking spinner
            duration = 1000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { thinkingAngle = it.animatedValue as Float; invalidate() }
        }
        animators.forEach { it.start() }
    }

    override fun onDetachedFromWindow() {
        animators.forEach { it.cancel() }
        animators.clear()
        colorAnimator?.cancel()
        super.onDetachedFromWindow()
    }

    // ---------------------------------------------------------------- drawing

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) / 2f * 0.45f
        val active = state == State.LISTENING || state == State.SPEAKING
        val scale = if (state == State.IDLE) pulse else 1f + smoothAmp * 0.12f
        val r = base * scale

        // 1. glow
        fill.shader = RadialGradient(
            cx, cy, base * 1.6f * scale,
            intArrayOf(withAlpha(curInner, glowAlpha), withAlpha(curOuter, 0)),
            floatArrayOf(0.3f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, base * 1.6f * scale, fill)

        // 2. core sphere
        fill.shader = RadialGradient(
            cx - r * 0.25f, cy - r * 0.25f, r * 1.3f,
            intArrayOf(curInner, curOuter), null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, fill)
        fill.shader = null

        // 3. rotating dashed rings
        val ringAlpha = if (active) 230 else if (state == State.THINKING) 120 else 70
        for (i in 0 until 3) {
            stroke.shader = null
            stroke.color = withAlpha(curInner, ringAlpha)
            stroke.strokeWidth = 2.5f
            stroke.pathEffect = DashPathEffect(floatArrayOf(18f + i * 8f, 14f), 0f)
            val dir = if (i % 2 == 0) 1f else -0.7f
            canvas.save()
            canvas.rotate(rotationAngle * dir * (1f + i * 0.3f), cx, cy)
            canvas.drawCircle(cx, cy, r * (1.18f + i * 0.14f), stroke)
            canvas.restore()
        }
        stroke.pathEffect = null

        // 4. wave rings (amplitude-reactive sine waves around the core)
        if (active) {
            for (w in 0 until 2) {
                path.reset()
                val amp = r * (0.03f + smoothAmp * 0.14f) * (if (state == State.SPEAKING) 1.4f else 1f)
                val speed = if (state == State.SPEAKING) 1.6f else 1f
                var a = 0
                while (a <= 360) {
                    val rad = a * PI.toFloat() / 180f
                    val rr = r * (1.08f + w * 0.1f) + sin(rad * 6 + waveOffset * speed + w * 1.5f) * amp
                    val x = cx + cos(rad) * rr
                    val y = cy + sin(rad) * rr
                    if (a == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    a += 4
                }
                path.close()
                stroke.color = withAlpha(curOuter, 200 - w * 80)
                stroke.strokeWidth = 3f - w
                canvas.drawPath(path, stroke)
            }
        }

        // 5. thinking arcs
        if (state == State.THINKING) {
            stroke.color = curInner
            stroke.strokeWidth = 6f
            stroke.strokeCap = Paint.Cap.ROUND
            val rr = r * 1.35f
            arcRect.set(cx - rr, cy - rr, cx + rr, cy + rr)
            canvas.drawArc(arcRect, thinkingAngle, 80f, false, stroke)
            canvas.drawArc(arcRect, thinkingAngle + 180f, 50f, false, stroke)
            stroke.strokeCap = Paint.Cap.BUTT
        }

        // 6. particles (12 orbiting dots)
        if (active) {
            fill.color = withAlpha(curInner, 230)
            for (i in 0 until 12) {
                val ang = (rotationAngle * 2f + i * 30f) * PI.toFloat() / 180f
                val dist = r * (1.55f + smoothAmp * 0.25f + 0.08f * sin(waveOffset + i))
                val dotR = 3f + smoothAmp * 5f + (i % 3)
                canvas.drawCircle(cx + cos(ang) * dist, cy + sin(ang) * dist, dotR, fill)
            }
        }

        // 7. inner highlight
        fill.shader = RadialGradient(
            cx - r * 0.35f, cy - r * 0.4f, r * 0.55f,
            intArrayOf(0x66FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx - r * 0.35f, cy - r * 0.4f, r * 0.55f, fill)
        fill.shader = null
    }

    private fun withAlpha(color: Int, alpha: Int): Int =
        (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)
}
