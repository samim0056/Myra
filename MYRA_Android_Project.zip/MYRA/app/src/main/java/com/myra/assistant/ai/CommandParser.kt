package com.myra.assistant.ai

import com.myra.assistant.model.AppCommand

/**
 * Turns transcribed speech (Hinglish or English) into an [AppCommand].
 * Returns null when nothing matches, so Gemini just handles it as conversation.
 */
object CommandParser {

    private val PRIME_WORDS = listOf(
        "close friend", "closefriend", "meri jaan", "meri jan", "my love",
        "my darling", "jaan ko", "prime contact", "prime"
    )
    private val SECOND = listOf("second", "2nd", "dusra", "doosra", "dusre", "doosre")
    private val THIRD = listOf("third", "3rd", "teesra", "tisra", "teesre")

    private val CALL_WORDS = listOf("call", "phone karo", "phone laga", "dial", "ring")
    private val MSG_WORDS = listOf("message", "msg", "sms", "text", "sandesh", "bhejo", "bhej do", "likho")
    private val WHATSAPP = listOf("whatsapp", "whats app", "watsapp", "व्हाट्सएप")

    private val OPEN_VERBS = Regex("""\b(kholo|khol do|khol de|kholna|open|launch|start|chalu karo|chalao|lagao)\b""")
    private val CLOSE_VERBS = Regex("""\b(band karo|band kar do|band kar|band|close|exit|kill|hatao)\b""")
    private val ON_WORDS = Regex("""\b(on|chalu|start|enable|jalao|jala do|kholo)\b""")
    private val OFF_WORDS = Regex("""\b(off|band|stop|disable|bujhao|bujha do|bandh)\b""")

    private val FILLERS = Regex(
        """\b(please|plz|myra|mujhe|mere liye|meri|mera|mere|ko|ka|ki|ke|se|to|the|my|a|an|on|in|pe|par|app|application|karo|kar do|kar|do|de|zara|jaldi)\b"""
    )

    // Devanagari speech-to-text output -> Roman keywords the parser understands
    private val DEV_PHRASES = listOf(
        "यू ट्यूब" to "youtube", "वाई फाई" to "wifi", "व्हाट्स ऐप" to "whatsapp", "गूगल मैप्स" to "maps",
        "मेरी जान" to "meri jaan", "माय लव" to "my love", "क्लोज फ्रेंड" to "close friend",
        "खोल दो" to "kholo", "कर दो" to "kar do", "बंद कर" to "band kar"
    )
    private val DEV_WORDS = mapOf(
        "इंस्टाग्राम" to "instagram", "इंस्टा" to "instagram", "यूट्यूब" to "youtube",
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "वाट्सएप" to "whatsapp",
        "फेसबुक" to "facebook", "क्रोम" to "chrome", "जीमेल" to "gmail", "मैप्स" to "maps", "गूगल" to "google",
        "टेलीग्राम" to "telegram", "स्नैपचैट" to "snapchat", "स्पॉटिफाई" to "spotify", "नेटफ्लिक्स" to "netflix",
        "ट्विटर" to "twitter", "कैलकुलेटर" to "calculator", "कैलेंडर" to "calendar", "सेटिंग्स" to "settings",
        "सेटिंग" to "settings", "कैमरा" to "camera", "सेल्फी" to "selfie", "फोटो" to "photo",
        "स्क्रीनशॉट" to "screenshot", "टॉर्च" to "torch", "फ्लैशलाइट" to "flashlight", "वाईफाई" to "wifi",
        "वाई-फाई" to "wifi", "ब्लूटूथ" to "bluetooth", "वॉल्यूम" to "volume", "आवाज़" to "volume", "आवाज" to "volume",
        "बढ़ाओ" to "badhao", "बढ़ा" to "badhao", "घटाओ" to "kam", "कम" to "kam", "सॉन्ग" to "song", "सोंग" to "song",
        "गाना" to "gana", "गाने" to "gana", "म्यूजिक" to "music", "प्ले" to "play", "पॉज" to "pause",
        "रोको" to "ruko", "नेक्स्ट" to "next", "अगला" to "agla", "पिछला" to "pichla", "ओपन" to "open",
        "खोलो" to "kholo", "खोल" to "kholo", "बंद" to "band", "चालू" to "chalu", "शुरू" to "start", "क्लोज" to "close",
        "कॉल" to "call", "फोन" to "phone", "मैसेज" to "message", "संदेश" to "message", "एसएमएस" to "sms",
        "भेजो" to "bhejo", "नोट" to "note", "नोट्स" to "notes", "मौसम" to "mausam", "तापमान" to "temperature",
        "न्यूज़" to "news", "न्यूज" to "news", "खबर" to "khabar", "खबरें" to "khabren", "समाचार" to "samachar",
        "सर्च" to "search", "करो" to "karo", "कर" to "kar", "दो" to "do", "का" to "ka", "को" to "ko",
        "में" to "me", "पर" to "par", "पे" to "pe", "लगाओ" to "lagao", "बजाओ" to "bajao", "चलाओ" to "chalao",
        "सुनाओ" to "sunao", "बताओ" to "batao", "दिखाओ" to "dikhao", "स्क्रीन" to "screen"
    )

    private fun transliterate(input: String): String {
        if (!Regex("[\\u0900-\\u097F]").containsMatchIn(input)) return input
        var t = " $input "
        DEV_PHRASES.forEach { (k, v) -> t = t.replace(" $k ", " $v ") }
        return t.trim().split(Regex("[\\s।,.!?]+")).filter { it.isNotBlank() }
            .joinToString(" ") { DEV_WORDS[it] ?: it }
    }

    fun parse(input: String): AppCommand? {
        val text = normalize(transliterate(input))
        if (text.isBlank()) return null

        // ---- 1. Device toggles ----
        parseDevice(text)?.let { return it }

        // ---- 1b. Media, camera, screenshot, notes, weather, news, search ----
        parseExtras(text)?.let { return it }

        val hasCall = CALL_WORDS.any { text.contains(it) }
        val hasMsg = MSG_WORDS.any { text.contains(it) }
        val hasWhatsapp = WHATSAPP.any { text.contains(it) }
        val hasPrime = PRIME_WORDS.any { text.contains(it) }

        // ---- 2. Prime contacts ----
        if (hasPrime && (hasCall || hasMsg || hasWhatsapp)) {
            val index = when {
                SECOND.any { text.contains(it) } -> 1
                THIRD.any { text.contains(it) } -> 2
                else -> 0
            }
            val params = mutableMapOf("index" to index.toString())
            return if (hasCall && !hasMsg) {
                AppCommand(AppCommand.PRIME_CALL, params)
            } else {
                extractMessageBody(text)?.let { params["message"] = it }
                AppCommand(AppCommand.PRIME_MSG, params)
            }
        }

        // ---- 3. WhatsApp message / call ----
        if (hasWhatsapp && (hasCall || hasMsg || text.contains(" ko ") || Regex("""whatsapp\s+(karo|kar do)""").containsMatchIn(text))) {
            val target = extractTarget(text, WHATSAPP + CALL_WORDS + MSG_WORDS)
            val params = targetParams(target)
            extractMessageBody(text)?.let { params["message"] = it }
            return AppCommand(if (hasCall && !hasMsg) AppCommand.WHATSAPP_CALL else AppCommand.WHATSAPP_MSG, params)
        }

        // ---- 4. SMS ----
        if (hasMsg && (text.contains("sms") || text.contains("message") || text.contains("msg") || text.contains("text"))
            && !hasCall
        ) {
            val target = extractTarget(text, MSG_WORDS)
            if (target.isNotBlank()) {
                val params = targetParams(target)
                extractMessageBody(text)?.let { params["message"] = it }
                return AppCommand(AppCommand.SMS, params)
            }
        }

        // ---- 5. Call ----
        if (hasCall) {
            val target = extractTarget(text, CALL_WORDS)
            if (target.isNotBlank()) return AppCommand(AppCommand.CALL, targetParams(target))
        }

        // ---- 6. Close / open app ----
        if (CLOSE_VERBS.containsMatchIn(text)) {
            val app = cleanAppName(CLOSE_VERBS.replace(text, " "))
            if (app.isNotBlank()) return AppCommand(AppCommand.CLOSE_APP, mapOf("app_name" to app))
        }
        if (OPEN_VERBS.containsMatchIn(text)) {
            val app = cleanAppName(OPEN_VERBS.replace(text, " "))
            if (app.isNotBlank()) return AppCommand(AppCommand.OPEN_APP, mapOf("app_name" to app))
        }

        return null
    }

    // ---------------- Device toggles ----------------

    private fun parseDevice(text: String): AppCommand? {
        // Volume
        if (text.contains("volume") || text.contains("awaz") || text.contains("awaaz") || text.contains("sound")) {
            val up = Regex("""\b(up|badhao|badha|zyada|increase|louder|tez|jyada|high)\b""").containsMatchIn(text)
            val down = Regex("""\b(down|kam|ghata|ghatao|decrease|lower|slow|dheere|low)\b""").containsMatchIn(text)
            if (up && !down) return AppCommand(AppCommand.VOLUME_UP)
            if (down && !up) return AppCommand(AppCommand.VOLUME_DOWN)
        }
        // Flashlight
        if (Regex("""\b(torch|flashlight|flash light|flash|light)\b""").containsMatchIn(text) &&
            !text.contains("highlight")
        ) {
            if (OFF_WORDS.containsMatchIn(text) && !Regex("""\bon\b""").containsMatchIn(text))
                return AppCommand(AppCommand.FLASHLIGHT_OFF)
            if (ON_WORDS.containsMatchIn(text)) return AppCommand(AppCommand.FLASHLIGHT_ON)
        }
        // WiFi
        if (Regex("""\b(wifi|wi fi|wi-fi|वाईफाई)\b""").containsMatchIn(text)) {
            if (Regex("""\boff\b|\bband\b|\bdisable\b|\bbandh\b""").containsMatchIn(text)) return AppCommand(AppCommand.WIFI_OFF)
            if (ON_WORDS.containsMatchIn(text)) return AppCommand(AppCommand.WIFI_ON)
        }
        // Bluetooth
        if (text.contains("bluetooth") || text.contains("blue tooth")) {
            if (Regex("""\boff\b|\bband\b|\bdisable\b|\bbandh\b""").containsMatchIn(text)) return AppCommand(AppCommand.BLUETOOTH_OFF)
            if (ON_WORDS.containsMatchIn(text)) return AppCommand(AppCommand.BLUETOOTH_ON)
        }
        return null
    }


    // ---------------- Extra features ----------------

    private val MEDIA_NOUN = Regex("""\b(song|songs|gana|gaana|gaane|track|music|video|videos|playing|bajna)\b""")
    private val YT_WORDS = setOf(
        "youtube", "yt", "you", "tube", "play", "search", "bajao", "baja", "chalao", "dekho", "dekhna",
        "dikhao", "lagao", "khojo", "dhundo", "pe", "par", "on", "in", "mein", "me", "karo", "kar", "do",
        "de", "ka", "ke", "ki", "ko", "video", "videos", "song", "songs", "gana", "gaana", "gaane",
        "music", "myra", "please", "mujhe", "mere", "liye", "the", "a", "for", "some", "kuch"
    )
    private val WEATHER_WORDS = setOf(
        "weather", "mausam", "temperature", "tapman", "garmi", "barish", "baarish", "aaj", "kal", "today",
        "kaisa", "kaisi", "hai", "batao", "bata", "do", "kya", "how", "is", "the", "in", "of", "me", "mein",
        "ka", "ki", "ke", "current", "abhi", "kitna", "kitni", "hain", "myra", "please", "ho", "raha", "rahi",
        "report", "forecast", "for", "at", "sunao", "suna"
    )
    private val NEWS_WORDS = setOf(
        "news", "khabar", "khabren", "khabrein", "samachar", "headlines", "headline", "aaj", "ki", "ka", "ke",
        "latest", "taaza", "batao", "bata", "sunao", "suna", "do", "dikhao", "top", "kya", "hai", "hain",
        "mein", "me", "about", "on", "baare", "bare", "today", "read", "myra", "please", "kuch", "koi",
        "for", "the", "padho", "de", "sab"
    )
    private val SEARCH_WORDS = setOf(
        "google", "search", "karo", "kar", "do", "de", "pe", "par", "on", "for", "about", "dhundo", "dhoondo",
        "khojo", "web", "internet", "me", "mein", "se", "ke", "baare", "bare", "ki", "ka", "ko", "myra",
        "please", "mujhe", "the", "a", "ye", "yeh"
    )
    private val NOTE_START_STRIP = setOf(
        "note", "notes", "karo", "kar", "likho", "likh", "me", "mein", "add", "save", "ye", "yeh", "this",
        "please", "myra", "ki", "that", "yaad", "rakho", "rakhna", "remember", "ko", "ek"
    )
    private val NOTE_END_STRIP = NOTE_START_STRIP + setOf("do", "lo", "de")

    private fun stripTokens(text: String, words: Set<String>): String =
        text.split(" ").filter { it.isNotBlank() && it !in words }.joinToString(" ").trim()

    private fun parseExtras(text: String): AppCommand? {
        val tokens = text.split(" ").filter { it.isNotBlank() }
        val hasNoun = MEDIA_NOUN.containsMatchIn(text)
        val hasYoutube = Regex("""\b(youtube|yt|you tube)\b""").containsMatchIn(text)
        val sendish = Regex("""\b(bhejo|bhej|send|message|msg|sms|whatsapp|call)\b""").containsMatchIn(text)

        // ---- screenshot ----
        if (Regex("""\b(screenshot|screen shot|screen capture)\b""").containsMatchIn(text))
            return AppCommand(AppCommand.SCREENSHOT)

        // ---- notes ----
        if (Regex("""\b(note|notes)\b""").containsMatchIn(text) || text.startsWith("yaad rakho") || text.startsWith("remember")) {
            val addVerb = Regex("""\b(likho|likh|add|save|rakho|remember)\b""").containsMatchIn(text)
            val opensApp = OPEN_VERBS.containsMatchIn(text) || Regex("""\bapp\b""").containsMatchIn(text)
            if (!opensApp) {
                if (!addVerb && Regex("""\b(delete|clear|hatao|mita|mitao|saaf|remove)\b""").containsMatchIn(text))
                    return AppCommand(AppCommand.NOTE_CLEAR)
                if (!addVerb && Regex("""\b(dikhao|dikha|padho|padh|sunao|suna|batao|bata|read|show|list)\b""").containsMatchIn(text))
                    return AppCommand(AppCommand.NOTE_READ)
                val list = tokens.toMutableList()
                while (list.isNotEmpty() && list.first() in NOTE_START_STRIP) list.removeAt(0)
                while (list.isNotEmpty() && list.last() in NOTE_END_STRIP) list.removeAt(list.size - 1)
                val body = list.joinToString(" ")
                if (body.isNotBlank()) return AppCommand(AppCommand.NOTE_ADD, mapOf("text" to body))
            }
        }

        // ---- camera ----
        if (!hasYoutube && !sendish &&
            Regex("""\b(camera|selfie|photo|pic|picture|foto)\b""").containsMatchIn(text)
        ) {
            val mode = when {
                text.contains("selfie") || text.contains("front camera") -> "selfie"
                text.contains("video") -> "video"
                else -> "photo"
            }
            return AppCommand(AppCommand.CAMERA, mapOf("mode" to mode))
        }
        if (Regex("""\b(record video|video record|video banao|video shoot)\b""").containsMatchIn(text))
            return AppCommand(AppCommand.CAMERA, mapOf("mode" to "video"))

        // ---- weather ----
        if (Regex("""\b(weather|mausam|temperature|tapman)\b""").containsMatchIn(text)) {
            val city = stripTokens(text, WEATHER_WORDS)
            return AppCommand(AppCommand.WEATHER, if (city.isNotBlank()) mapOf("city" to city) else emptyMap())
        }

        // ---- news ----
        if (Regex("""\b(news|khabar|khabren|khabrein|samachar|headlines?)\b""").containsMatchIn(text) && !OPEN_VERBS.containsMatchIn(text)) {
            val topic = stripTokens(text, NEWS_WORDS)
            return AppCommand(AppCommand.NEWS, if (topic.isNotBlank()) mapOf("topic" to topic) else emptyMap())
        }

        // ---- YouTube search / play ----
        if (hasYoutube && Regex("""\b(play|search|bajao|chalao|dekho|dekhna|dikhao|lagao|khojo|dhundo)\b""").containsMatchIn(text)) {
            val q = stripTokens(text, YT_WORDS)
            if (q.isNotBlank()) return AppCommand(AppCommand.YOUTUBE_SEARCH, mapOf("query" to q))
        }

        // ---- media controls ----
        val short = tokens.size <= 3
        if (Regex("""\b(next|agla|agle|skip)\b""").containsMatchIn(text) && (hasNoun || short))
            return AppCommand(AppCommand.MEDIA_NEXT)
        if (Regex("""\b(previous|prev|pichla|pichle)\b""").containsMatchIn(text) && (hasNoun || short))
            return AppCommand(AppCommand.MEDIA_PREV)
        if (Regex("""\b(pause|ruko|roko|rok)\b""").containsMatchIn(text) && (hasNoun || short))
            return AppCommand(AppCommand.MEDIA_PAUSE)
        if (Regex("""\b(stop|band)\b""").containsMatchIn(text) &&
            Regex("""\b(song|songs|gana|gaana|gaane|track|music|playing)\b""").containsMatchIn(text)
        ) return AppCommand(AppCommand.MEDIA_PAUSE)

        if (!text.contains("store") && Regex("""\b(play|resume)\b""").containsMatchIn(text) ||
            (hasNoun && Regex("""\b(chalao|bajao|baja|chalu|lagao)\b""").containsMatchIn(text))
        ) {
            val q = stripTokens(text, YT_WORDS + setOf("resume", "chalu", "baja"))
            if (q.isBlank() && (hasNoun || short)) return AppCommand(AppCommand.MEDIA_PLAY)
            if (q.isNotBlank() && text.startsWith("play"))
                return AppCommand(AppCommand.YOUTUBE_SEARCH, mapOf("query" to q))
        }

        // ---- web search ----
        if (!hasYoutube && Regex("""\b(search|dhundo|dhoondo|khojo|google (karo|kar|pe|par|se))\b""").containsMatchIn(text)) {
            val q = stripTokens(text, SEARCH_WORDS)
            if (q.isNotBlank()) return AppCommand(AppCommand.WEB_SEARCH, mapOf("query" to q))
        }
        return null
    }

    // ---------------- Helpers ----------------

    private fun normalize(s: String): String =
        s.lowercase()
            .replace(Regex("""[.,!?;:"'`]"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()

    /** Removes the given trigger words, filler words, and any message body to leave the contact name/number. */
    private fun extractTarget(text: String, triggers: List<String>): String {
        var t = text
        // cut off message body first
        t = Regex("""\b(saying|says|that|bolo|bol do|bolna|ki|message is|msg is|likho)\b.*$""").replace(t, " ")
        // digits-only number?
        Regex("""\+?\d[\d\s-]{6,}""").find(t)?.let { return it.value.replace(Regex("""[\s-]"""), "") }

        for (w in triggers.sortedByDescending { it.length }) t = t.replace(w, " ")
        t = t.replace(Regex("""\b(bhejo|bhej|karo|kar do|send|make|a|ek)\b"""), " ")
        t = FILLERS.replace(t, " ")
        return t.replace(Regex("""\s+"""), " ").trim()
    }

    private fun targetParams(target: String): MutableMap<String, String> {
        val params = mutableMapOf<String, String>()
        if (target.isBlank()) return params
        if (target.replace("+", "").all { it.isDigit() }) params["number"] = target
        else params["name"] = target
        return params
    }

    private fun extractMessageBody(text: String): String? {
        val m = Regex("""\b(?:saying|says|that|bolo|bol do|bolna|message is|msg is|likho|ki)\s+(.+)$""").find(text)
        return m?.groupValues?.get(1)?.trim()?.takeIf { it.isNotEmpty() }
    }

    private fun cleanAppName(s: String): String =
        FILLERS.replace(s, " ")
            .replace(Regex("[\\u0900-\\u097F]+"), " ")
            .replace(Regex("""\b(now|abhi|yaar|bhai|ye|yeh|woh)\b"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
}
