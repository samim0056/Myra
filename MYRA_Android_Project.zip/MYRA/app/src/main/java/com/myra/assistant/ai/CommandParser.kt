package com.myra.assistant.ai

import com.myra.assistant.model.AppCommand

/**
 * Turns transcribed speech (Hinglish or English) into an [AppCommand].
 * Returns null when nothing matches, so Gemini just handles it as conversation.
 */
object CommandParser {

    private val PRIME_WORDS = listOf(
        "close friend", "closefriend", "meri jaan", "meri jan", "my love",
        "my darling", "jaan ko", "prime contact", "prime"
    )
    private val SECOND = listOf("second", "2nd", "dusra", "doosra", "dusre", "doosre")
    private val THIRD = listOf("third", "3rd", "teesra", "tisra", "teesre")

    private val CALL_WORDS = listOf("call", "phone karo", "phone laga", "dial", "ring")
    private val MSG_WORDS = listOf("message", "msg", "sms", "text", "sandesh", "bhejo", "bhej do", "likho")
    private val WHATSAPP = listOf("whatsapp", "whats app", "watsapp", "व्हाट्सएप")

    private val OPEN_VERBS = Regex("""\b(kholo|khol do|khol de|kholna|open|launch|start|chalu karo|chalao|lagao)\b""")
    private val CLOSE_VERBS = Regex("""\b(band karo|band kar do|band kar|band|close|exit|kill|hatao)\b""")
    private val ON_WORDS = Regex("""\b(on|chalu|start|enable|jalao|jala do|kholo)\b""")
    private val OFF_WORDS = Regex("""\b(off|band|stop|disable|bujhao|bujha do|bandh)\b""")

    private val FILLERS = Regex(
        """\b(please|plz|myra|mujhe|mere liye|meri|mera|mere|ko|ka|ki|ke|se|to|the|my|a|an|app|application|karo|kar do|kar|do|de|zara|jaldi)\b"""
    )

    fun parse(input: String): AppCommand? {
        val text = normalize(input)
        if (text.isBlank()) return null

        // ---- 1. Device toggles ----
        parseDevice(text)?.let { return it }

        val hasCall = CALL_WORDS.any { text.contains(it) }
        val hasMsg = MSG_WORDS.any { text.contains(it) }
        val hasWhatsapp = WHATSAPP.any { text.contains(it) }
        val hasPrime = PRIME_WORDS.any { text.contains(it) }

        // ---- 2. Prime contacts ----
        if (hasPrime && (hasCall || hasMsg || hasWhatsapp)) {
            val index = when {
                SECOND.any { text.contains(it) } -> 1
                THIRD.any { text.contains(it) } -> 2
                else -> 0
            }
            val params = mutableMapOf("index" to index.toString())
            return if (hasCall && !hasMsg) {
                AppCommand(AppCommand.PRIME_CALL, params)
            } else {
                extractMessageBody(text)?.let { params["message"] = it }
                AppCommand(AppCommand.PRIME_MSG, params)
            }
        }

        // ---- 3. WhatsApp message / call ----
        if (hasWhatsapp && (hasCall || hasMsg || text.contains(" ko ") || Regex("""whatsapp\s+(karo|kar do)""").containsMatchIn(text))) {
            val target = extractTarget(text, WHATSAPP + CALL_WORDS + MSG_WORDS)
            val params = targetParams(target)
            extractMessageBody(text)?.let { params["message"] = it }
            return AppCommand(if (hasCall && !hasMsg) AppCommand.WHATSAPP_CALL else AppCommand.WHATSAPP_MSG, params)
        }

        // ---- 4. SMS ----
        if (hasMsg && (text.contains("sms") || text.contains("message") || text.contains("msg") || text.contains("text"))
            && !hasCall
        ) {
            val target = extractTarget(text, MSG_WORDS)
            if (target.isNotBlank()) {
                val params = targetParams(target)
                extractMessageBody(text)?.let { params["message"] = it }
                return AppCommand(AppCommand.SMS, params)
            }
        }

        // ---- 5. Call ----
        if (hasCall) {
            val target = extractTarget(text, CALL_WORDS)
            if (target.isNotBlank()) return AppCommand(AppCommand.CALL, targetParams(target))
        }

        // ---- 6. Close / open app ----
        if (CLOSE_VERBS.containsMatchIn(text)) {
            val app = cleanAppName(CLOSE_VERBS.replace(text, " "))
            if (app.isNotBlank()) return AppCommand(AppCommand.CLOSE_APP, mapOf("app_name" to app))
        }
        if (OPEN_VERBS.containsMatchIn(text)) {
            val app = cleanAppName(OPEN_VERBS.replace(text, " "))
            if (app.isNotBlank()) return AppCommand(AppCommand.OPEN_APP, mapOf("app_name" to app))
        }

        return null
    }

    // ---------------- Device toggles ----------------

    private fun parseDevice(text: String): AppCommand? {
        // Volume
        if (text.contains("volume") || text.contains("awaz") || text.contains("awaaz") || text.contains("sound")) {
            val up = Regex("""\b(up|badhao|badha|zyada|increase|louder|tez|jyada|high)\b""").containsMatchIn(text)
            val down = Regex("""\b(down|kam|ghata|ghatao|decrease|lower|slow|dheere|low)\b""").containsMatchIn(text)
            if (up && !down) return AppCommand(AppCommand.VOLUME_UP)
            if (down && !up) return AppCommand(AppCommand.VOLUME_DOWN)
        }
        // Flashlight
        if (Regex("""\b(torch|flashlight|flash light|flash|light)\b""").containsMatchIn(text) &&
            !text.contains("highlight")
        ) {
            if (OFF_WORDS.containsMatchIn(text) && !Regex("""\bon\b""").containsMatchIn(text))
                return AppCommand(AppCommand.FLASHLIGHT_OFF)
            if (ON_WORDS.containsMatchIn(text)) return AppCommand(AppCommand.FLASHLIGHT_ON)
        }
        // WiFi
        if (Regex("""\b(wifi|wi fi|wi-fi|वाईफाई)\b""").containsMatchIn(text)) {
            if (Regex("""\boff\b|\bband\b|\bdisable\b|\bbandh\b""").containsMatchIn(text)) return AppCommand(AppCommand.WIFI_OFF)
            if (ON_WORDS.containsMatchIn(text)) return AppCommand(AppCommand.WIFI_ON)
        }
        // Bluetooth
        if (text.contains("bluetooth") || text.contains("blue tooth")) {
            if (Regex("""\boff\b|\bband\b|\bdisable\b|\bbandh\b""").containsMatchIn(text)) return AppCommand(AppCommand.BLUETOOTH_OFF)
            if (ON_WORDS.containsMatchIn(text)) return AppCommand(AppCommand.BLUETOOTH_ON)
        }
        return null
    }

    // ---------------- Helpers ----------------

    private fun normalize(s: String): String =
        s.lowercase()
            .replace(Regex("""[.,!?;:"'`]"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()

    /** Removes the given trigger words, filler words, and any message body to leave the contact name/number. */
    private fun extractTarget(text: String, triggers: List<String>): String {
        var t = text
        // cut off message body first
        t = Regex("""\b(saying|says|that|bolo|bol do|bolna|ki|message is|msg is|likho)\b.*$""").replace(t, " ")
        // digits-only number?
        Regex("""\+?\d[\d\s-]{6,}""").find(t)?.let { return it.value.replace(Regex("""[\s-]"""), "") }

        for (w in triggers.sortedByDescending { it.length }) t = t.replace(w, " ")
        t = t.replace(Regex("""\b(bhejo|bhej|karo|kar do|send|make|a|ek)\b"""), " ")
        t = FILLERS.replace(t, " ")
        return t.replace(Regex("""\s+"""), " ").trim()
    }

    private fun targetParams(target: String): MutableMap<String, String> {
        val params = mutableMapOf<String, String>()
        if (target.isBlank()) return params
        if (target.replace("+", "").all { it.isDigit() }) params["number"] = target
        else params["name"] = target
        return params
    }

    private fun extractMessageBody(text: String): String? {
        val m = Regex("""\b(?:saying|says|that|bolo|bol do|bolna|message is|msg is|likho|ki)\s+(.+)$""").find(text)
        return m?.groupValues?.get(1)?.trim()?.takeIf { it.isNotEmpty() }
    }

    private fun cleanAppName(s: String): String =
        FILLERS.replace(s, " ")
            .replace(Regex("""\b(now|abhi|yaar|bhai|ye|yeh|woh)\b"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
}
