package com.myra.assistant.ui.main

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.myra.assistant.R
import kotlin.random.Random

// ------------------------------------------------------------------ Waveform

/** 20-bar waveform; bars lerp toward amplitude-driven targets. */
class WaveformView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val barCount = 20
    private val barHeights = FloatArray(barCount)
    private val targets = FloatArray(barCount)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF1744.toInt() }
    private val rect = RectF()
    private var running = false

    private val frame = object : Runnable {
        override fun run() {
            if (!running) return
            var changed = false
            for (i in 0 until barCount) {
                val d = targets[i] - barHeights[i]
                if (kotlin.math.abs(d) > 0.002f) { barHeights[i] += d * 0.3f; changed = true }
                targets[i] *= 0.9f          // decay when no new amplitude arrives
            }
            if (changed) invalidate()
            postOnAnimation(this)
        }
    }

    fun startAnimation() {
        if (running) return
        running = true
        postOnAnimation(frame)
    }

    fun stopAnimation() {
        running = false
        targets.fill(0f)
        barHeights.fill(0f)
        invalidate()
    }

    /** rms: 0..1 */
    fun setAmplitude(rms: Float) {
        val a = rms.coerceIn(0f, 1f)
        for (i in 0 until barCount) {
            val centre = 1f - kotlin.math.abs(i - (barCount - 1) / 2f) / (barCount / 2f) * 0.5f
            targets[i] = (a * centre * (0.6f + Random.nextFloat() * 0.4f)).coerceIn(0f, 1f)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); startAnimation() }
    override fun onDetachedFromWindow() { running = false; super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val slot = width.toFloat() / barCount
        val barW = slot * 0.55f
        val minH = 4f * resources.displayMetrics.density
        for (i in 0 until barCount) {
            val h = minH + barHeights[i] * (height - minH)
            val left = i * slot + (slot - barW) / 2
            val top = (height - h) / 2
            paint.alpha = (150 + barHeights[i] * 105).toInt().coerceIn(150, 255)
            rect.set(left, top, left + barW, top + h)
            canvas.drawRoundRect(rect, barW / 2, barW / 2, paint)
        }
    }
}

// ------------------------------------------------------------------ Chat

data class ChatMessage(val text: String, val isUser: Boolean, val timestamp: Long = System.currentTimeMillis())

class ChatAdapter : RecyclerView.Adapter<ChatAdapter.VH>() {

    private val items = mutableListOf<ChatMessage>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val text: TextView = v.findViewById(R.id.chatText)
    }

    /** Adds a message. MYRA messages identical to the last MYRA message are skipped. */
    fun addMessage(text: String, isUser: Boolean): Boolean {
        if (text.isBlank()) return false
        if (!isUser && lastMyraText() == text) return false
        items.add(ChatMessage(text, isUser))
        notifyItemInserted(items.size - 1)
        return true
    }

    fun lastMyraText(): String? = items.lastOrNull { !it.isUser }?.text

    override fun getItemViewType(position: Int) = if (items[position].isUser) 0 else 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = if (viewType == 0) R.layout.item_chat_user else R.layout.item_chat_myra
        return VH(LayoutInflater.from(parent.context).inflate(layout, parent, false))
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.text.text = items[position].text
    }

    override fun getItemCount() = items.size
}
