package com.myra.assistant.model

/** A phone action parsed from the user's speech. */
data class AppCommand(
    val type: String,
    val params: Map<String, String> = emptyMap()
) {
    companion object {
        const val OPEN_APP = "OPEN_APP"
        const val CLOSE_APP = "CLOSE_APP"
        const val CALL = "CALL"
        const val SMS = "SMS"
        const val WHATSAPP_MSG = "WHATSAPP_MSG"
        const val WHATSAPP_CALL = "WHATSAPP_CALL"
        const val PRIME_CALL = "PRIME_CALL"
        const val PRIME_MSG = "PRIME_MSG"
        const val VOLUME_UP = "VOLUME_UP"
        const val VOLUME_DOWN = "VOLUME_DOWN"
        const val FLASHLIGHT_ON = "FLASHLIGHT_ON"
        const val FLASHLIGHT_OFF = "FLASHLIGHT_OFF"
        const val WIFI_ON = "WIFI_ON"
        const val WIFI_OFF = "WIFI_OFF"
        const val BLUETOOTH_ON = "BLUETOOTH_ON"
        const val BLUETOOTH_OFF = "BLUETOOTH_OFF"
        const val MEDIA_PLAY = "MEDIA_PLAY"
        const val MEDIA_PAUSE = "MEDIA_PAUSE"
        const val MEDIA_NEXT = "MEDIA_NEXT"
        const val MEDIA_PREV = "MEDIA_PREV"
        const val YOUTUBE_SEARCH = "YOUTUBE_SEARCH"
        const val SCREENSHOT = "SCREENSHOT"
        const val CAMERA = "CAMERA"
        const val NOTE_ADD = "NOTE_ADD"
        const val NOTE_READ = "NOTE_READ"
        const val NOTE_CLEAR = "NOTE_CLEAR"
        const val WEATHER = "WEATHER"
        const val NEWS = "NEWS"
        const val WEB_SEARCH = "WEB_SEARCH"
    }
}
