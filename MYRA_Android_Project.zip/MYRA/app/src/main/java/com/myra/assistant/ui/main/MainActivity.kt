package com.myra.assistant.ui.main

import android.Manifest
import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.myra.assistant.R
import com.myra.assistant.ai.AudioEngine
import com.myra.assistant.ai.CommandParser
import com.myra.assistant.ai.GeminiLiveClient
import com.myra.assistant.ai.Personality
import com.myra.assistant.service.CallMonitorService
import com.myra.assistant.service.MyraOverlayService
import com.myra.assistant.ui.settings.SettingsActivity
import com.myra.assistant.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_INCOMING_CALL = "INCOMING_CALL"
        const val EXTRA_CALLER_NAME = "CALLER_NAME"
        const val ACTION_CALL_ENDED = "com.myra.CALL_ENDED"
    }

    private lateinit var viewModel: MainViewModel
    private var geminiLive: GeminiLiveClient? = null
    private var audioEngine: AudioEngine? = null

    // views
    private lateinit var orb: OrbAnimationView
    private lateinit var waveform: WaveformView
    private lateinit var statusText: TextView
    private lateinit var redOverlay: View
    private lateinit var micButton: ImageButton
    private lateinit var chatRecycler: RecyclerView
    private lateinit var batteryText: TextView
    private lateinit var ramText: TextView
    private lateinit var timeText: TextView
    private val chatAdapter = ChatAdapter()

    private val ui = Handler(Looper.getMainLooper())
    private val inputBuffer = StringBuilder()
    private val outputBuffer = StringBuilder()

    private var isMuted = false
    private var isInCallMode = false
    private var greeted = false
    private var pendingCaller: String? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var callRetries = 0
    private var dropAudio = false          // after long-press stop: ignore audio until the turn ends
    private var toolCallsTotal = 0
    private var toolCallsSinceFlush = 0

    private val prefs by lazy { getSharedPreferences(GeminiLiveClient.PREFS, MODE_PRIVATE) }

    private val callEndedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { exitCallMode() }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { onPermissionsResult() }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        viewModel = ViewModelProvider(this)[MainViewModel::class.java]

        initViews()
        checkPermissions()
        startSystemServices()
        startStatusUpdates()

        ContextCompat.registerReceiver(
            this, callEndedReceiver, IntentFilter(ACTION_CALL_ENDED), ContextCompat.RECEIVER_NOT_EXPORTED
        )

        // Phone-command results are spoken back by MYRA
        viewModel.commandResult.observe(this) { result ->
            if (!result.isNullOrBlank()) {
                viewModel.consumeResult()
                val how = if (result.length > 90) "Ye jaankari user ko apni awaaz me saaf aur chhote tareeke se suna do."
                          else "User ko is baare me ek chhote vaakya me batao."
                geminiLive?.sendText("[Phone action result: $result] $how")
            }
        }

        ui.postDelayed({ initGeminiLive() }, 300)
        handleIncomingCallIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingCallIntent(intent)
    }

    override fun onPause() {
        super.onPause()
        audioEngine?.setMuted(true)
    }

    override fun onResume() {
        super.onResume()
        if (!isMuted) audioEngine?.setMuted(false)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        geminiLive?.disconnect()
        audioEngine?.release()
        speechRecognizer?.destroy()
        runCatching { unregisterReceiver(callEndedReceiver) }
        super.onDestroy()
    }

    // ------------------------------------------------------------------ init

    private fun initViews() {
        orb = findViewById(R.id.orbView)
        waveform = findViewById(R.id.waveformView)
        statusText = findViewById(R.id.statusText)
        redOverlay = findViewById(R.id.redOverlay)
        micButton = findViewById(R.id.micButton)
        chatRecycler = findViewById(R.id.chatRecycler)
        batteryText = findViewById(R.id.batteryText)
        ramText = findViewById(R.id.ramText)
        timeText = findViewById(R.id.timeText)

        // transparent status bar, dark nav bar
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.parseColor("#050505")
        val root = findViewById<View>(R.id.rootLayout)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, 0, 0, bars.bottom)
            insets
        }

        chatRecycler.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        chatRecycler.adapter = chatAdapter

        findViewById<ImageButton>(R.id.settingsBtn).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        micButton.setOnClickListener { toggleMute() }
        micButton.setOnLongClickListener {
            // stop MYRA mid-sentence
            dropAudio = true
            audioEngine?.clearPlayback()
            geminiLive?.interrupt()
            setStatus("Ruk gayi... bolo")
            true
        }
        updateMicButton()
        setStatus("Connect ho rahi hoon...")
    }

    private fun initGeminiLive() {
        val g = GeminiLiveClient(this)
        val a = AudioEngine(this)
        geminiLive = g
        audioEngine = a

        g.onConnected = { ui.post { onGeminiConnected() } }
        g.onDisconnected = {
            ui.post {
                orb.setState(OrbAnimationView.State.IDLE)
                setStatus("Reconnect ho rahi hoon...")
            }
        }
        g.onAudioReceived = { if (!dropAudio) a.queueAudio(it) }
        g.onInterrupted = { a.clearPlayback() }
        g.onInputTranscript = { t ->
            ui.post {
                inputBuffer.append(t)
                dropAudio = false
                if (a.isSpeaking.not()) orb.setState(OrbAnimationView.State.THINKING)
            }
        }
        g.onOutputTranscript = { t -> ui.post { outputBuffer.append(t) } }
        g.onTurnComplete = { ui.post { flushTranscripts() } }
        g.onError = { msg ->
            ui.post {
                setStatus(
                    when {
                        msg.contains("1008") -> "Model nahi mila. Settings me 'Gemini 3.8 Live' chuno, Save karo, app restart karo"
                        msg.contains("1007") -> "Model config error. Settings me Live Google Search off karke dekho"
                        else -> msg
                    }
                )
            }
        }
        g.onToolCall = { id, name, args -> ui.post { handleToolCall(id, name, args) } }

        a.onMicChunk = { chunk -> if (!isInCallMode) g.sendAudio(chunk) }
        a.onAmplitudeChanged = { amp ->
            ui.post { waveform.setAmplitude(amp); orb.setAmplitude(amp) }
        }
        a.onSpeakingStarted = {
            ui.post {
                orb.setState(OrbAnimationView.State.SPEAKING)
                setStatus("Bol rahi hoon...")
                fadeRed(true)
            }
        }
        a.onSpeakingStopped = {
            ui.post {
                if (!isInCallMode) {
                    orb.setState(OrbAnimationView.State.LISTENING)
                    setStatus("Sun rahi hoon...")
                }
            }
        }

        g.connect()
    }

    private fun onGeminiConnected() {
        audioEngine?.startRecording()
        audioEngine?.startPlayback()
        audioEngine?.setMuted(isMuted)
        orb.setState(OrbAnimationView.State.LISTENING)
        setStatus("Sun rahi hoon...")
        updateMicButton()

        val caller = pendingCaller
        if (caller != null) {
            pendingCaller = null
            announceCall(caller)
        } else if (!greeted) {
            greeted = true
            ui.postDelayed({ sendGreeting() }, 600)
        }
    }

    private fun sendGreeting() {
        val mode = prefs.getString("personality_mode", "GF") ?: "GF"
        val name = prefs.getString("user_name", "") ?: ""
        geminiLive?.sendText(Personality.greeting(mode, name))
    }

    // ------------------------------------------------------------------ transcripts + commands

    private fun flushTranscripts() {
        val user = inputBuffer.toString().trim()
        val myra = outputBuffer.toString().trim()
        inputBuffer.clear(); outputBuffer.clear()

        var added = false
        if (user.isNotEmpty()) added = chatAdapter.addMessage(user, true) || added
        if (myra.isNotEmpty()) added = chatAdapter.addMessage(myra, false) || added
        if (added) chatRecycler.scrollToPosition(chatAdapter.itemCount - 1)

        if (!isInCallMode && audioEngine?.isSpeaking != true) {
            orb.setState(OrbAnimationView.State.LISTENING)
            fadeRed(false)
        }

        dropAudio = false

        // Primary path = Gemini function calling (handleToolCall). The transcript parser is only a
        // fallback when the model did not call phone_command for this turn.
        val hadToolCall = toolCallsSinceFlush > 0
        toolCallsSinceFlush = 0
        if (!hadToolCall && user.isNotEmpty()) {
            val cmd = CommandParser.parse(user)
            if (cmd != null) {
                val snapshot = toolCallsTotal
                ui.postDelayed({ if (toolCallsTotal == snapshot) viewModel.execute(cmd) }, 1500)
            }
        }
    }

    private fun handleToolCall(id: String, name: String, args: org.json.JSONObject) {
        toolCallsTotal++
        toolCallsSinceFlush++
        val g = geminiLive ?: return
        val text = args.optString("command")
        val cmd = CommandParser.parse(text)
        if (cmd == null) {
            g.sendToolResponse(id, name, "Command samajh nahi aaya: '$text'. User se dobara saaf bolne ko kaho")
        } else {
            viewModel.executeAsync(cmd) { result -> g.sendToolResponse(id, name, result) }
        }
    }

    // ------------------------------------------------------------------ mic button

    private fun toggleMute() {
        isMuted = !isMuted
        audioEngine?.setMuted(isMuted)
        updateMicButton()
        if (isMuted) {
            setStatus("Mic band hai")
            orb.setState(OrbAnimationView.State.IDLE)
            fadeRed(false)
        } else {
            setStatus("Sun rahi hoon...")
            orb.setState(OrbAnimationView.State.LISTENING)
        }
    }

    private fun updateMicButton() {
        val listening = !isMuted && geminiLive?.isReady == true
        micButton.setImageResource(if (listening) R.drawable.ic_mic_on else R.drawable.ic_mic_off)
    }

    // ------------------------------------------------------------------ incoming call

    private fun handleIncomingCallIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(EXTRA_INCOMING_CALL, false) != true) return
        val name = intent.getStringExtra(EXTRA_CALLER_NAME) ?: "Unknown"
        intent.removeExtra(EXTRA_INCOMING_CALL)
        if (geminiLive?.isReady == true) announceCall(name) else pendingCaller = name
    }

    private fun announceCall(callerName: String) {
        isInCallMode = true
        callRetries = 0
        setActiveMode(true)
        geminiLive?.sendText("Sir, $callerName ka call aa raha hai. Uthau ya reject karu?")
        ui.postDelayed({ startCallListening() }, 4500)
    }

    private fun startCallListening() {
        if (!isInCallMode) return
        if (!SpeechRecognizer.isRecognitionAvailable(this) ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            setStatus("Speech recognition available nahi hai")
            return
        }
        audioEngine?.stopRecording()      // free the mic for STT
        setStatus("Bolo: uthao ya reject")

        speechRecognizer?.destroy()
        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer = sr
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: emptyList()
                handleCallDecision(list)
            }
            override fun onError(error: Int) { retryCallListening() }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        sr.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        )
    }

    private fun retryCallListening() {
        if (!isInCallMode) return
        if (callRetries++ < 3) ui.postDelayed({ startCallListening() }, 500)
        else setStatus("Call: samajh nahi aaya")
    }

    private fun handleCallDecision(texts: List<String>) {
        val words = texts.joinToString(" ").lowercase().split(Regex("""\W+""")).toSet()
        val reject = setOf("reject", "nahi", "nahin", "mat", "cut", "decline", "kaat", "kato", "no", "cancel")
        val accept = setOf("uthao", "utha", "uthalo", "uthale", "haan", "han", "ha", "accept", "receive", "answer", "pick", "yes")
        when {
            words.any { it in reject } -> viewModel.rejectCall()
            words.any { it in accept } -> viewModel.acceptCall()
            else -> { retryCallListening(); return }
        }
        setActiveMode(false)     // MYRA back to standby; mic resumes on CALL_ENDED
    }

    private fun exitCallMode() {
        if (!isInCallMode && speechRecognizer == null) return
        isInCallMode = false
        speechRecognizer?.destroy(); speechRecognizer = null
        audioEngine?.startRecording()
        setActiveMode(false)
    }

    /** Active: red screen glow + listening orb. Standby: idle orb, glow off. */
    private fun setActiveMode(active: Boolean) {
        fadeRed(active)
        orb.setState(if (active) OrbAnimationView.State.LISTENING else OrbAnimationView.State.IDLE)
        if (!active) setStatus("Standby")
    }

    // ------------------------------------------------------------------ UI helpers

    private fun setStatus(text: String) { statusText.text = text }

    private fun fadeRed(on: Boolean) {
        redOverlay.animate().cancel()
        redOverlay.animate().alpha(if (on) 0.08f else 0f).setDuration(if (on) 300 else 500).start()
    }

    private val statusRunnable = object : Runnable {
        override fun run() {
            val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
            batteryText.text = "${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%"

            val mi = ActivityManager.MemoryInfo()
            (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            ramText.text = "RAM ${100 - (mi.availMem * 100 / mi.totalMem)}%"

            timeText.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            ui.postDelayed(this, 30_000)
        }
    }

    private fun startStatusUpdates() { statusRunnable.run() }

    // ------------------------------------------------------------------ permissions + services

    private fun checkPermissions() {
        val needed = mutableListOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_CALL_LOG
        )
        if (Build.VERSION.SDK_INT >= 33) needed += Manifest.permission.POST_NOTIFICATIONS
        if (Build.VERSION.SDK_INT >= 31) needed += Manifest.permission.BLUETOOTH_CONNECT

        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray()) else requestOverlayIfNeeded()
    }

    private fun onPermissionsResult() {
        startSystemServices()
        audioEngine?.let { if (geminiLive?.isReady == true) it.startRecording() }
        requestOverlayIfNeeded()
    }

    private fun requestOverlayIfNeeded() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission do (double power press ke liye)", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    private fun startSystemServices() {
        try {
            val phoneOk = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
            if (phoneOk) ContextCompat.startForegroundService(this, Intent(this, CallMonitorService::class.java))

            val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (micOk && !MyraOverlayService.isRunning) {
                ContextCompat.startForegroundService(this, Intent(this, MyraOverlayService::class.java))
            }
        } catch (e: Exception) {
            // service start can fail on restricted devices; app still works without them
        }
    }
}
