# OkHttp / Okio
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }
# org.json
-keep class org.json.** { *; }
# Kotlin coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }
# Services/receivers referenced from the manifest
-keep class com.myra.assistant.service.** { *; }
-keep class com.myra.assistant.ui.main.OrbAnimationView { *; }
-keep class com.myra.assistant.ui.main.WaveformView { *; }
